"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { GraduationCap, Users, ClipboardCheck, TrendingUp, Loader2, LogIn, BarChart3 } from "lucide-react";
import { api, saveSession, type Session, type LoginResponse } from "@/lib/lms";
import { useToast } from "@/hooks/use-toast";

const DEMO_FACULTY = [
  { email: "anil.sharma@lms.edu", name: "Dr. Anil Sharma" },
  { email: "meera.iyer@lms.edu", name: "Prof. Meera Iyer" },
  { email: "rajesh.gupta@lms.edu", name: "Dr. Rajesh Gupta" },
];

const DEMO_STUDENTS = [
  { email: "aarav.mehta@lms.edu", name: "Aarav Mehta" },
  { email: "vivaan.rana@lms.edu", name: "Vivaan Rana (irregular)" },
  { email: "kavya.nair@lms.edu", name: "Kavya Nair" },
];

export default function LoginView({ onLogin }: { onLogin: (s: Session) => void }) {
  const { toast } = useToast();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function doLogin(e?: React.FormEvent, demoEmail?: string, demoPw?: string) {
    e?.preventDefault();
    const em = demoEmail ?? email;
    const pw = demoPw ?? password;
    if (!em || !pw) {
      setError("Please enter both email and password");
      return;
    }
    setBusy(true);
    setError(null);
    try {
      const res = await api<LoginResponse>("/api/auth/login", {
        method: "POST",
        body: JSON.stringify({ email: em, password: pw }),
      });
      const session: Session = { token: res.token, user: res.user, profile: res.profile };
      saveSession(session);
      onLogin(session);
      toast({ title: `Welcome, ${res.user.name}`, description: `Signed in as ${res.user.role === "FACULTY" ? "Faculty" : "Student"}` });
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="min-h-screen flex flex-col lg:flex-row bg-slate-50">
      {/* Branding panel */}
      <div className="lg:w-[55%] bg-gradient-to-br from-emerald-700 via-emerald-600 to-teal-700 text-white flex flex-col justify-between p-8 lg:p-14 relative overflow-hidden">
        <div className="absolute -top-24 -right-24 w-96 h-96 rounded-full bg-white/5" />
        <div className="absolute bottom-10 -left-20 w-80 h-80 rounded-full bg-white/5" />
        <div className="relative">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-white/15 backdrop-blur flex items-center justify-center">
              <GraduationCap className="w-7 h-7" />
            </div>
            <div>
              <h1 className="text-2xl font-bold tracking-tight">EduTrack LMS</h1>
              <p className="text-emerald-100 text-sm">Learning Management System</p>
            </div>
          </div>
        </div>

        <div className="relative my-10 lg:my-0">
          <h2 className="text-3xl lg:text-4xl font-bold leading-tight max-w-lg">
            Track attendance, marks & student progress — all in one place.
          </h2>
          <p className="mt-4 text-emerald-100 max-w-md">
            A complete platform for faculty and students of the Computer Science department.
          </p>
          <div className="mt-8 grid sm:grid-cols-2 gap-4 max-w-lg">
            {[
              { icon: ClipboardCheck, title: "Smart Attendance", desc: "Daily marking, auto %, at-risk alerts" },
              { icon: BarChart3, title: "Instant Reports", desc: "Attendance & internal mark reports" },
              { icon: TrendingUp, title: "Progress Tracking", desc: "Semester-wise exam history & SGPA" },
              { icon: Users, title: "40+ Students", desc: "Full department dataset onboarded" },
            ].map((f) => (
              <div key={f.title} className="flex items-start gap-3 rounded-xl bg-white/10 backdrop-blur p-4">
                <f.icon className="w-5 h-5 mt-0.5 shrink-0" />
                <div>
                  <p className="font-semibold text-sm">{f.title}</p>
                  <p className="text-emerald-100 text-xs mt-0.5">{f.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <p className="relative text-emerald-200 text-xs">Semester 5 · Academic Year 2026-27 · Computer Science & Engineering</p>
      </div>

      {/* Login panel */}
      <div className="lg:w-[45%] flex items-center justify-center p-6 lg:p-12">
        <div className="w-full max-w-md">
          <Card className="border-none shadow-xl shadow-slate-200">
            <CardHeader className="pb-2">
              <CardTitle className="text-2xl">Sign in</CardTitle>
              <CardDescription>Use your institutional credentials to continue</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={doLogin} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="name@lms.edu"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    autoComplete="username"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="password">Password</Label>
                  <Input
                    id="password"
                    type="password"
                    placeholder="••••••••"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    autoComplete="current-password"
                  />
                </div>
                {error && (
                  <p className="text-sm text-rose-600 bg-rose-50 border border-rose-200 rounded-md px-3 py-2">{error}</p>
                )}
                <Button type="submit" className="w-full bg-emerald-600 hover:bg-emerald-700" disabled={busy}>
                  {busy ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <LogIn className="w-4 h-4 mr-2" />}
                  {busy ? "Signing in…" : "Sign in"}
                </Button>
              </form>

              <Tabs defaultValue="faculty" className="mt-6">
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="faculty">Faculty demos</TabsTrigger>
                  <TabsTrigger value="student">Student demos</TabsTrigger>
                </TabsList>
                <TabsContent value="faculty" className="mt-3 space-y-2">
                  {DEMO_FACULTY.map((f) => (
                    <button
                      key={f.email}
                      type="button"
                      onClick={() => doLogin(undefined, f.email, "faculty123")}
                      className="w-full text-left rounded-lg border border-slate-200 hover:border-emerald-400 hover:bg-emerald-50/60 px-3 py-2 transition-colors"
                    >
                      <p className="text-sm font-medium">{f.name}</p>
                      <p className="text-xs text-slate-500">{f.email} · password: faculty123</p>
                    </button>
                  ))}
                </TabsContent>
                <TabsContent value="student" className="mt-3 space-y-2">
                  {DEMO_STUDENTS.map((s) => (
                    <button
                      key={s.email}
                      type="button"
                      onClick={() => doLogin(undefined, s.email, "student123")}
                      className="w-full text-left rounded-lg border border-slate-200 hover:border-emerald-400 hover:bg-emerald-50/60 px-3 py-2 transition-colors"
                    >
                      <p className="text-sm font-medium">{s.name}</p>
                      <p className="text-xs text-slate-500">{s.email} · password: student123</p>
                    </button>
                  ))}
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
