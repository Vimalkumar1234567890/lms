"use client";

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  ResponsiveContainer, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip,
  BarChart, Bar, Cell,
} from "recharts";
import { Users, BookOpen, CalendarCheck, Percent, AlertTriangle, CalendarX2 } from "lucide-react";
import { StatCard, LoadingBlock, ErrorBlock } from "@/components/lms/shared";
import { useFetch, type Session } from "@/lib/lms";

interface OverviewData {
  totals: {
    students: number; faculty: number; courses: number; classSessions: number;
    avgAttendance: number; avgInternal: number; atRiskCount: number; todayMarked: boolean;
  };
  trend: { date: string; label: string; pct: number }[];
  courseStats: {
    courseId: string; code: string; name: string; facultyName: string; isMine: boolean;
    attendancePct: number; internalPct: number; students: number;
  }[];
  gradeDist: { range: string; count: number }[];
  atRisk: { studentId: string; name: string; rollNo: string; section: string; attendancePct: number }[];
  lowPerformers: { studentId: string; name: string; rollNo: string; internalPct: number }[];
}

export default function Overview({ session }: { session: Session }) {
  const { data, loading, error } = useFetch<OverviewData>("/api/faculty/overview", session);
  if (loading) return <LoadingBlock height="h-72" />;
  if (error || !data) return <ErrorBlock message={error ?? "unknown"} />;

  const t = data.totals;
  const barColors = ["#059669", "#0d9488", "#d97706", "#dc2626", "#7c3aed", "#65a30d"];

  return (
    <div className="space-y-5">
      {/* stat cards */}
      <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-3">
        <StatCard icon={Users} label="Students" value={t.students} sub="Semester 5 · CSE" />
        <StatCard icon={BookOpen} label="Courses" value={t.courses} sub={`${t.classSessions} class days`} tone="teal" />
        <StatCard icon={Percent} label="Avg Attendance" value={`${t.avgAttendance}%`} tone={t.avgAttendance >= 85 ? "emerald" : "amber"} />
        <StatCard icon={CalendarCheck} label="Avg Internal" value={`${t.avgInternal}%`} sub="out of 95" tone="orange" />
        <StatCard icon={AlertTriangle} label="Below 75% Att." value={t.atRiskCount} sub="need attention" tone="rose" />
        <StatCard icon={CalendarX2} label="Today" value={t.todayMarked ? "Marked" : "Pending"} sub={t.todayMarked ? "attendance done" : "not marked yet"} tone={t.todayMarked ? "emerald" : "amber"} />
      </div>

      {/* charts row */}
      <div className="grid lg:grid-cols-5 gap-4">
        <Card className="lg:col-span-3 border-slate-200">
          <CardHeader className="pb-2">
            <CardTitle className="text-base">Department Attendance Trend</CardTitle>
            <CardDescription>Class-wise present % across all courses (last 14 sessions)</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={data.trend} margin={{ top: 5, right: 10, left: -18, bottom: 0 }}>
                  <defs>
                    <linearGradient id="attGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#059669" stopOpacity={0.35} />
                      <stop offset="100%" stopColor="#059669" stopOpacity={0.02} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
                  <XAxis dataKey="label" tick={{ fontSize: 11 }} tickLine={false} axisLine={{ stroke: "#cbd5e1" }} interval={1} />
                  <YAxis domain={[50, 100]} tick={{ fontSize: 11 }} tickLine={false} axisLine={false} unit="%" />
                  <Tooltip formatter={(v) => [`${v}%`, "Present"]} contentStyle={{ borderRadius: 8, fontSize: 12 }} />
                  <Area type="monotone" dataKey="pct" stroke="#059669" strokeWidth={2.5} fill="url(#attGrad)" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <Card className="lg:col-span-2 border-slate-200">
          <CardHeader className="pb-2">
            <CardTitle className="text-base">Internal Marks Distribution</CardTitle>
            <CardDescription>Students by total internal % (out of 95)</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={data.gradeDist} margin={{ top: 5, right: 10, left: -22, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
                  <XAxis dataKey="range" tick={{ fontSize: 11 }} tickLine={false} axisLine={{ stroke: "#cbd5e1" }} />
                  <YAxis tick={{ fontSize: 11 }} tickLine={false} axisLine={false} allowDecimals={false} />
                  <Tooltip formatter={(v) => [`${v} students`, "Count"]} contentStyle={{ borderRadius: 8, fontSize: 12 }} />
                  <Bar dataKey="count" radius={[6, 6, 0, 0]} maxBarSize={44}>
                    {data.gradeDist.map((_, i) => (
                      <Cell key={i} fill={barColors[i % barColors.length]} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* course stats */}
      <Card className="border-slate-200">
        <CardHeader className="pb-2">
          <CardTitle className="text-base">Course-wise Performance</CardTitle>
          <CardDescription>Attendance vs internal marks average per course</CardDescription>
        </CardHeader>
        <CardContent className="grid sm:grid-cols-2 xl:grid-cols-3 gap-3">
          {data.courseStats.map((c) => (
            <div key={c.courseId} className="rounded-xl border border-slate-200 p-3.5 hover:border-emerald-300 transition-colors">
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0">
                  <p className="font-semibold text-sm text-slate-800">
                    {c.code} {c.isMine && <Badge className="ml-1 bg-emerald-100 text-emerald-700 hover:bg-emerald-100">your course</Badge>}
                  </p>
                  <p className="text-xs text-slate-500 truncate">{c.name}</p>
                </div>
                <span className="text-[11px] text-slate-400 shrink-0">{c.students} students</span>
              </div>
              <div className="mt-3 space-y-2">
                <div>
                  <div className="flex justify-between text-[11px] mb-1">
                    <span className="text-slate-500">Attendance</span>
                    <span className="font-semibold text-slate-700">{c.attendancePct}%</span>
                  </div>
                  <Progress value={c.attendancePct} className="h-1.5 [&>div]:bg-emerald-500" />
                </div>
                <div>
                  <div className="flex justify-between text-[11px] mb-1">
                    <span className="text-slate-500">Internal avg</span>
                    <span className="font-semibold text-slate-700">{c.internalPct}%</span>
                  </div>
                  <Progress value={c.internalPct} className="h-1.5 [&>div]:bg-teal-500" />
                </div>
              </div>
              <p className="text-[11px] text-slate-400 mt-2.5">Instructor: {c.facultyName}</p>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* at risk + low performers */}
      <div className="grid lg:grid-cols-2 gap-4">
        <Card className="border-slate-200">
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-rose-500" /> Attendance Below 75%
            </CardTitle>
            <CardDescription>Students barred from exams as per norms — inform & follow up</CardDescription>
          </CardHeader>
          <CardContent>
            {data.atRisk.length === 0 ? (
              <p className="text-sm text-slate-500 py-4 text-center">All students are above 75% — well done!</p>
            ) : (
              <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
                {data.atRisk.map((s) => (
                  <div key={s.studentId} className="flex items-center justify-between rounded-lg border border-rose-100 bg-rose-50/50 px-3 py-2">
                    <div>
                      <p className="text-sm font-medium text-slate-800">{s.name}</p>
                      <p className="text-xs text-slate-500">{s.rollNo} · Section {s.section}</p>
                    </div>
                    <Badge variant="destructive">{s.attendancePct}%</Badge>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="border-slate-200">
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <Percent className="w-4 h-4 text-amber-500" /> Internal Marks Below 55%
            </CardTitle>
            <CardDescription>Students needing academic support this semester</CardDescription>
          </CardHeader>
          <CardContent>
            {data.lowPerformers.length === 0 ? (
              <p className="text-sm text-slate-500 py-4 text-center">No student is below 55% internally.</p>
            ) : (
              <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
                {data.lowPerformers.map((s) => (
                  <div key={s.studentId} className="flex items-center justify-between rounded-lg border border-amber-100 bg-amber-50/50 px-3 py-2">
                    <div>
                      <p className="text-sm font-medium text-slate-800">{s.name}</p>
                      <p className="text-xs text-slate-500">{s.rollNo}</p>
                    </div>
                    <Badge className="bg-amber-100 text-amber-800 hover:bg-amber-100">{s.internalPct}%</Badge>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
