"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardAction } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { CheckCircle2, XCircle, Clock, Save, CheckCheck, Eraser, CalendarDays, Loader2 } from "lucide-react";
import { api, todayISO, fmtDate, useFetch, type Session, type CourseInfo } from "@/lib/lms";
import { useToast } from "@/hooks/use-toast";

type Status = "PRESENT" | "ABSENT" | "LATE";
interface RosterRow {
  studentId: string; rollNo: string; name: string; section: string;
  status: Status | null; note: string;
}
interface RosterData {
  course: { id: string; code: string; name: string };
  date: string;
  roster: RosterRow[];
  alreadyMarked: boolean;
}

export default function AttendanceMarker({ session }: { session: Session }) {
  const { toast } = useToast();
  const [courses, setCourses] = useState<CourseInfo[]>([]);
  const [courseId, setCourseId] = useState<string>("");
  const [date, setDate] = useState<string>(todayISO());
  const [rows, setRows] = useState<RosterRow[]>([]);
  const [loadingRoster, setLoadingRoster] = useState(false);
  const [alreadyMarked, setAlreadyMarked] = useState(false);
  const [saving, setSaving] = useState(false);
  const [course, setCourse] = useState<{ code: string; name: string } | null>(null);

  useEffect(() => {
    api<{ courses: CourseInfo[] }>("/api/courses", { session }).then((d) => {
      setCourses(d.courses);
      if (d.courses.length > 0) setCourseId((prev) => prev || d.courses[0].id);
    });
  }, [session]);

  const loadRoster = useCallback(async () => {
    if (!courseId || !date) return;
    setLoadingRoster(true);
    try {
      const d = await api<RosterData>(
        `/api/faculty/attendance?courseId=${courseId}&date=${date}`,
        { session }
      );
      setRows(d.roster);
      setAlreadyMarked(d.alreadyMarked);
      setCourse(d.course);
    } catch (e) {
      toast({ title: "Could not load roster", description: (e as Error).message, variant: "destructive" });
    } finally {
      setLoadingRoster(false);
    }
  }, [courseId, date, session, toast]);

  useEffect(() => {
    loadRoster();
  }, [loadRoster]);

  const counts = useMemo(() => {
    const present = rows.filter((r) => r.status === "PRESENT").length;
    const late = rows.filter((r) => r.status === "LATE").length;
    const absent = rows.filter((r) => r.status === "ABSENT").length;
    const marked = present + late + absent;
    return { present, late, absent, marked, total: rows.length };
  }, [rows]);

  function setStatus(studentId: string, status: Status) {
    setRows((prev) => prev.map((r) => (r.studentId === studentId ? { ...r, status } : r)));
  }
  function setNote(studentId: string, note: string) {
    setRows((prev) => prev.map((r) => (r.studentId === studentId ? { ...r, note } : r)));
  }
  function markAll(status: Status) {
    setRows((prev) => prev.map((r) => ({ ...r, status })));
  }

  async function save() {
    if (!courseId) return;
    const records = rows.filter((r) => r.status !== null).map((r) => ({ studentId: r.studentId, status: r.status, note: r.note }));
    if (records.length === 0) {
      toast({ title: "Nothing to save", description: "Mark at least one student first.", variant: "destructive" });
      return;
    }
    setSaving(true);
    try {
      const res = await api<{ saved: number; courseCode: string }>("/api/faculty/attendance", {
        method: "POST",
        session,
        body: JSON.stringify({ courseId, date, records }),
      });
      toast({
        title: `Attendance saved — ${res.courseCode}`,
        description: `${res.saved} students · ${date}: ${counts.present} present, ${counts.late} late, ${counts.absent} absent`,
      });
      setAlreadyMarked(true);
    } catch (e) {
      toast({ title: "Save failed", description: (e as Error).message, variant: "destructive" });
    } finally {
      setSaving(false);
    }
  }

  const statusBtn = (row: RosterRow, status: Status, icon: React.ReactNode, activeCls: string, label: string) => (
    <button
      type="button"
      aria-label={`${label} for ${row.name}`}
      onClick={() => setStatus(row.studentId, status)}
      className={`inline-flex items-center justify-center w-8 h-8 rounded-lg border transition-all ${
        row.status === status
          ? `${activeCls} border-transparent shadow-sm`
          : "border-slate-200 bg-white text-slate-400 hover:bg-slate-50 hover:text-slate-600"
      }`}
    >
      {icon}
    </button>
  );

  return (
    <div className="space-y-4">
      <Card className="border-slate-200">
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <CalendarDays className="w-4 h-4 text-emerald-600" /> Mark Daily Attendance
          </CardTitle>
          <CardDescription>Pick a course and date, mark each student, then save. Existing records are updated.</CardDescription>
        </CardHeader>
        <CardContent className="flex flex-col sm:flex-row gap-3 sm:items-end">
          <div className="flex-1 min-w-48 space-y-1.5">
            <label className="text-xs font-medium text-slate-500">Course</label>
            <Select value={courseId} onValueChange={setCourseId}>
              <SelectTrigger className="w-full bg-white"><SelectValue placeholder="Select course" /></SelectTrigger>
              <SelectContent>
                {courses.map((c) => (
                  <SelectItem key={c.id} value={c.id}>
                    {c.code} — {c.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <label className="text-xs font-medium text-slate-500">Date</label>
            <Input type="date" value={date} max={todayISO()} onChange={(e) => setDate(e.target.value)} className="bg-white w-full sm:w-44" />
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={() => markAll("PRESENT")} className="border-emerald-200 text-emerald-700 hover:bg-emerald-50">
              <CheckCheck className="w-4 h-4 mr-1" /> All present
            </Button>
            <Button variant="outline" size="sm" onClick={() => markAll("ABSENT")} className="border-rose-200 text-rose-700 hover:bg-rose-50">
              <Eraser className="w-4 h-4 mr-1" /> Reset
            </Button>
          </div>
        </CardContent>
      </Card>

      {loadingRoster ? (
        <Skeleton className="h-96 w-full" />
      ) : (
        <Card className="border-slate-200">
          <CardHeader className="pb-3">
            <div>
              <CardTitle className="text-base">
                {course ? `${course.code} — ${course.name}` : "Roster"} · {fmtDate(date)}
              </CardTitle>
              <CardDescription className="mt-1">
                {alreadyMarked ? (
                  <span className="text-emerald-600 font-medium">Already recorded — you can edit and re-save.</span>
                ) : (
                  "Not marked yet for this date."
                )}
              </CardDescription>
            </div>
            <CardAction>
              <div className="flex items-center gap-2 text-xs flex-wrap">
                <Badge className="bg-emerald-100 text-emerald-700 hover:bg-emerald-100">{counts.present} present</Badge>
                <Badge className="bg-amber-100 text-amber-700 hover:bg-amber-100">{counts.late} late</Badge>
                <Badge className="bg-rose-100 text-rose-700 hover:bg-rose-100">{counts.absent} absent</Badge>
                <Badge variant="outline">{counts.marked}/{counts.total} marked</Badge>
              </div>
            </CardAction>
          </CardHeader>
          <CardContent>
            <div className="rounded-lg border border-slate-200 overflow-hidden">
              <div className="max-h-[26rem] overflow-y-auto">
                <Table>
                  <TableHeader className="bg-slate-50 sticky top-0 z-10">
                    <TableRow>
                      <TableHead className="w-14">Roll</TableHead>
                      <TableHead>Student</TableHead>
                      <TableHead className="hidden md:table-cell">Sec</TableHead>
                      <TableHead className="text-center w-36">Status</TableHead>
                      <TableHead className="hidden lg:table-cell w-56">Note (optional)</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {rows.map((r) => (
                      <TableRow key={r.studentId} className={r.status === "ABSENT" ? "bg-rose-50/40" : r.status === "LATE" ? "bg-amber-50/40" : ""}>
                        <TableCell className="font-mono text-xs text-slate-500">{r.rollNo.slice(-3)}</TableCell>
                        <TableCell className="font-medium text-sm">{r.name}</TableCell>
                        <TableCell className="hidden md:table-cell text-xs text-slate-500">{r.section}</TableCell>
                        <TableCell>
                          <div className="flex items-center justify-center gap-1.5">
                            {statusBtn(r, "PRESENT", <CheckCircle2 className="w-4.5 h-4.5" />, "bg-emerald-500 text-white", "Present")}
                            {statusBtn(r, "LATE", <Clock className="w-4.5 h-4.5" />, "bg-amber-500 text-white", "Late")}
                            {statusBtn(r, "ABSENT", <XCircle className="w-4.5 h-4.5" />, "bg-rose-500 text-white", "Absent")}
                          </div>
                        </TableCell>
                        <TableCell className="hidden lg:table-cell">
                          <Input
                            value={r.note}
                            onChange={(e) => setNote(r.studentId, e.target.value)}
                            placeholder="e.g. medical leave"
                            className="h-8 text-xs bg-white"
                          />
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </div>
            <div className="mt-4 flex items-center justify-between">
              <p className="text-xs text-slate-500">
                {counts.marked} of {counts.total} students marked
              </p>
              <Button onClick={save} disabled={saving || counts.marked === 0} className="bg-emerald-600 hover:bg-emerald-700">
                {saving ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Save className="w-4 h-4 mr-2" />}
                {saving ? "Saving…" : `Save attendance (${counts.marked})`}
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
