"use client";

import { useMemo, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from "recharts";
import { Search, TrendingUp, TrendingDown, Minus, Users, Phone, BookUser, ArrowUpDown } from "lucide-react";
import { LoadingBlock, ErrorBlock } from "@/components/lms/shared";
import { api, attColor, gradeBadgeClass, useFetch, type Session } from "@/lib/lms";

interface StudentRow {
  studentId: string; userId: string; rollNo: string; name: string; email: string; section: string; semester: number;
  attendancePct: number; internalPct: number; latestSgpa: number; prevSgpa: number; trend: string;
}
interface DetailData {
  profile: { studentId: string; name: string; email: string; rollNo: string; department: string; semester: number; section: string; phone: string | null; guardian: string | null };
  attendanceByCourse: { code: string; name: string; present: number; late: number; absent: number; total: number; pct: number }[];
  internalByCourse: { code: string; name: string; got: number; max: number; pct: number; perType: Record<string, number> }[];
  exams: { semester: number; academicYear: string; examType: string; courseCode: string; courseName: string; marks: number; maxMarks: number; grade: string }[];
  semesters: { semester: number; sgpa: number; avgPct: number }[];
  overallAttendancePct: number;
  recentAttendance: { date: string; courseCode: string; status: string }[];
}

type SortKey = "rollNo" | "name" | "attendancePct" | "internalPct" | "latestSgpa";

export default function Students({ session }: { session: Session }) {
  const [search, setSearch] = useState("");
  const [sortKey, setSortKey] = useState<SortKey>("rollNo");
  const [sortAsc, setSortAsc] = useState(true);
  const [selected, setSelected] = useState<StudentRow | null>(null);
  const [detail, setDetail] = useState<DetailData | null>(null);
  const [detailLoading, setDetailLoading] = useState(false);

  const { data, loading, error } = useFetch<{ rows: StudentRow[] }>("/api/faculty/students", session);

  async function openStudent(s: StudentRow) {
    setSelected(s);
    setDetail(null);
    setDetailLoading(true);
    try {
      const d = await api<DetailData>(`/api/faculty/student-detail?studentId=${s.studentId}`, { session });
      setDetail(d);
    } finally {
      setDetailLoading(false);
    }
  }

  const rows = useMemo(() => {
    let list = (data?.rows ?? []).filter(
      (r) =>
        search === "" ||
        r.name.toLowerCase().includes(search.toLowerCase()) ||
        r.rollNo.toLowerCase().includes(search.toLowerCase()) ||
        r.section.toLowerCase() === search.toLowerCase()
    );
    list = [...list].sort((a, b) => {
      const va = a[sortKey];
      const vb = b[sortKey];
      const cmp = typeof va === "string" ? String(va).localeCompare(String(vb)) : Number(va) - Number(vb);
      return sortAsc ? cmp : -cmp;
    });
    return list;
  }, [data, search, sortKey, sortAsc]);

  function sortBtn(key: SortKey, label: string) {
    const active = sortKey === key;
    return (
      <button
        type="button"
        className="inline-flex items-center gap-1 hover:text-emerald-700 transition-colors"
        onClick={() => {
          if (active) setSortAsc((v) => !v);
          else {
            setSortKey(key);
            setSortAsc(true);
          }
        }}
      >
        {label}
        <ArrowUpDown className={`w-3 h-3 ${active ? "text-emerald-600" : "text-slate-300"}`} />
      </button>
    );
  }

  const TrendIcon = ({ trend }: { trend: string }) =>
    trend === "up" ? (
      <span className="inline-flex items-center gap-1 text-emerald-600 text-xs font-medium"><TrendingUp className="w-3.5 h-3.5" /> up</span>
    ) : trend === "down" ? (
      <span className="inline-flex items-center gap-1 text-rose-600 text-xs font-medium"><TrendingDown className="w-3.5 h-3.5" /> down</span>
    ) : (
      <span className="inline-flex items-center gap-1 text-slate-400 text-xs font-medium"><Minus className="w-3.5 h-3.5" /> steady</span>
    );

  const progChart = (detail?.semesters ?? []).map((s) => ({
    semester: `Sem ${s.semester}`,
    sgpa: s.sgpa,
    avgPct: s.avgPct,
  }));

  return (
    <div className="space-y-4">
      <Card className="border-slate-200">
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <Users className="w-4 h-4 text-emerald-600" /> Students — Semester 5 CSE
          </CardTitle>
          <CardDescription>Click any student for the full progress report (attendance, internals, exam history).</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="relative max-w-sm">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-slate-400" />
            <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search name, roll no or section…" className="pl-8 bg-white" />
          </div>
        </CardContent>
      </Card>

      {loading ? <LoadingBlock height="h-96" /> : error ? <ErrorBlock message={error} /> : (
        <Card className="border-slate-200">
          <CardContent className="pt-4">
            <div className="rounded-lg border border-slate-200 overflow-hidden">
              <div className="max-h-[32rem] overflow-y-auto">
                <Table>
                  <TableHeader className="bg-slate-50 sticky top-0 z-10">
                    <TableRow>
                      <TableHead>{sortBtn("rollNo", "Roll")}</TableHead>
                      <TableHead>{sortBtn("name", "Student")}</TableHead>
                      <TableHead className="hidden md:table-cell">Sec</TableHead>
                      <TableHead className="w-44">{sortBtn("attendancePct", "Attendance")}</TableHead>
                      <TableHead className="w-44">{sortBtn("internalPct", "Internal")}</TableHead>
                      <TableHead className="text-center">{sortBtn("latestSgpa", "SGPA")}</TableHead>
                      <TableHead className="text-center">Trend</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {rows.map((r) => (
                      <TableRow
                        key={r.studentId}
                        className="cursor-pointer hover:bg-emerald-50/50"
                        onClick={() => openStudent(r)}
                      >
                        <TableCell className="font-mono text-xs text-slate-500">{r.rollNo}</TableCell>
                        <TableCell>
                          <p className="font-medium text-sm">{r.name}</p>
                          <p className="text-xs text-slate-400">{r.email}</p>
                        </TableCell>
                        <TableCell className="hidden md:table-cell text-xs text-slate-500">{r.section}</TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Progress
                              value={r.attendancePct}
                              className={`h-2 flex-1 ${r.attendancePct >= 85 ? "[&>div]:bg-emerald-500" : r.attendancePct >= 75 ? "[&>div]:bg-amber-500" : "[&>div]:bg-rose-500"}`}
                            />
                            <span className={`text-xs font-bold w-11 text-right ${attColor(r.attendancePct)}`}>{r.attendancePct}%</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Progress
                              value={r.internalPct}
                              className={`h-2 flex-1 ${r.internalPct >= 70 ? "[&>div]:bg-teal-500" : r.internalPct >= 55 ? "[&>div]:bg-amber-500" : "[&>div]:bg-rose-500"}`}
                            />
                            <span className={`text-xs font-bold w-11 text-right ${attColor(r.internalPct)}`}>{r.internalPct}%</span>
                          </div>
                        </TableCell>
                        <TableCell className="text-center">
                          <span className="font-bold text-slate-700">{r.latestSgpa}</span>
                          <span className="block text-[10px] text-slate-400">prev {r.prevSgpa}</span>
                        </TableCell>
                        <TableCell className="text-center"><TrendIcon trend={r.trend} /></TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* student detail dialog */}
      <Dialog open={!!selected} onOpenChange={(open) => !open && setSelected(null)}>
        <DialogContent className="max-w-3xl max-h-[88vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 flex-wrap">
              {selected?.name}
              <Badge variant="outline">{selected?.rollNo}</Badge>
              <Badge variant="outline">Section {selected?.section}</Badge>
              <Badge className="bg-emerald-100 text-emerald-700 hover:bg-emerald-100">SGPA {selected?.latestSgpa}</Badge>
            </DialogTitle>
            <DialogDescription>{selected?.email} · Semester {selected?.semester} · Computer Science</DialogDescription>
          </DialogHeader>

          {detailLoading || !detail ? (
            <Skeleton className="h-80 w-full" />
          ) : (
            <Tabs defaultValue="progress" className="mt-1">
              <TabsList className="w-full grid grid-cols-3">
                <TabsTrigger value="progress">Progress</TabsTrigger>
                <TabsTrigger value="attendance">Attendance</TabsTrigger>
                <TabsTrigger value="marks">Marks</TabsTrigger>
              </TabsList>

              <TabsContent value="progress" className="mt-3 space-y-3">
                <div className="h-56">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={progChart} margin={{ top: 5, right: 10, left: -18, bottom: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
                      <XAxis dataKey="semester" tick={{ fontSize: 11 }} tickLine={false} axisLine={{ stroke: "#cbd5e1" }} />
                      <YAxis yAxisId="left" domain={[40, 100]} tick={{ fontSize: 11 }} tickLine={false} axisLine={false} unit="%" />
                      <YAxis yAxisId="right" orientation="right" domain={[0, 10]} tick={{ fontSize: 11 }} tickLine={false} axisLine={false} />
                      <Tooltip contentStyle={{ borderRadius: 8, fontSize: 12 }} />
                      <Legend wrapperStyle={{ fontSize: 11 }} />
                      <Line yAxisId="left" type="monotone" dataKey="avgPct" name="Avg %" stroke="#0d9488" strokeWidth={2.5} dot={{ r: 3 }} />
                      <Line yAxisId="right" type="monotone" dataKey="sgpa" name="SGPA" stroke="#d97706" strokeWidth={2.5} dot={{ r: 3 }} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div className="rounded-lg border border-slate-200 p-3">
                    <p className="text-xs text-slate-500">Overall attendance</p>
                    <p className={`text-lg font-bold ${attColor(detail.overallAttendancePct)}`}>{detail.overallAttendancePct}%</p>
                  </div>
                  <div className="rounded-lg border border-slate-200 p-3">
                    <p className="text-xs text-slate-500 flex items-center gap-1"><Phone className="w-3 h-3" /> Contact</p>
                    <p className="text-sm font-medium text-slate-700 truncate">{detail.profile.phone ?? "—"}</p>
                    <p className="text-xs text-slate-400 truncate">Guardian: {detail.profile.guardian ?? "—"}</p>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="attendance" className="mt-3 space-y-2">
                {detail.attendanceByCourse.map((c) => (
                  <div key={c.code} className="rounded-lg border border-slate-200 px-3 py-2">
                    <div className="flex items-center justify-between text-sm">
                      <span className="font-medium">{c.code} <span className="text-slate-400 font-normal">· {c.name}</span></span>
                      <span className={`font-bold ${attColor(c.pct)}`}>{c.pct}%</span>
                    </div>
                    <div className="mt-1.5 flex items-center gap-2">
                      <Progress
                        value={c.pct}
                        className={`h-1.5 flex-1 ${c.pct >= 85 ? "[&>div]:bg-emerald-500" : c.pct >= 75 ? "[&>div]:bg-amber-500" : "[&>div]:bg-rose-500"}`}
                      />
                      <span className="text-[11px] text-slate-400">{c.present}P · {c.late}L · {c.absent}A</span>
                    </div>
                  </div>
                ))}
                <div className="mt-2">
                  <p className="text-xs font-medium text-slate-500 mb-1.5 flex items-center gap-1"><BookUser className="w-3 h-3" /> Recent sessions</p>
                  <div className="flex flex-wrap gap-1.5">
                    {detail.recentAttendance.map((r, i) => (
                      <span
                        key={i}
                        title={`${r.courseCode} · ${r.date}`}
                        className={`text-[10px] px-1.5 py-0.5 rounded border ${
                          r.status === "ABSENT"
                            ? "bg-rose-50 border-rose-200 text-rose-600"
                            : r.status === "LATE"
                            ? "bg-amber-50 border-amber-200 text-amber-600"
                            : "bg-emerald-50 border-emerald-200 text-emerald-600"
                        }`}
                      >
                        {r.courseCode} {r.status === "ABSENT" ? "A" : r.status === "LATE" ? "L" : "P"}
                      </span>
                    ))}
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="marks" className="mt-3 space-y-3">
                <div>
                  <p className="text-xs font-medium text-slate-500 mb-1.5">Internal marks (current semester)</p>
                  <div className="grid sm:grid-cols-2 gap-2">
                    {detail.internalByCourse.map((c) => (
                      <div key={c.code} className="rounded-lg border border-slate-200 px-3 py-2 text-sm">
                        <div className="flex items-center justify-between">
                          <span className="font-medium">{c.code}</span>
                          <span className={`font-bold ${attColor(c.pct)}`}>{c.got}/{c.max} ({c.pct}%)</span>
                        </div>
                        <p className="text-[11px] text-slate-400 mt-0.5">
                          Q1 {c.perType["QUIZ_1"] ?? "–"} · Q2 {c.perType["QUIZ_2"] ?? "–"} · Mid {c.perType["MID_TERM"] ?? "–"} · Asmt {c.perType["ASSIGNMENT"] ?? "–"} · Lab {c.perType["LAB"] ?? "–"}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>
                <div>
                  <p className="text-xs font-medium text-slate-500 mb-1.5">Exam history</p>
                  <div className="rounded-lg border border-slate-200 overflow-hidden">
                    <div className="max-h-56 overflow-y-auto">
                      <Table>
                        <TableHeader className="bg-slate-50">
                          <TableRow>
                            <TableHead>Sem</TableHead>
                            <TableHead>Course</TableHead>
                            <TableHead className="hidden sm:table-cell">Type</TableHead>
                            <TableHead className="text-center">Marks</TableHead>
                            <TableHead className="text-center">Grade</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {detail.exams.map((e, i) => (
                            <TableRow key={i}>
                              <TableCell className="text-xs">{e.semester}</TableCell>
                              <TableCell className="text-sm font-medium">{e.courseCode}</TableCell>
                              <TableCell className="hidden sm:table-cell text-xs text-slate-500">
                                {e.examType === "END_SEMESTER" ? "End-Sem" : "Mid-Sem"} · {e.academicYear}
                              </TableCell>
                              <TableCell className="text-center text-sm font-semibold">{e.marks}/{e.maxMarks}</TableCell>
                              <TableCell className="text-center">
                                <Badge className={`font-bold ${gradeBadgeClass(e.grade)}`}>{e.grade}</Badge>
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
