"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardAction } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Save, Loader2, PenLine, ListChecks, Download } from "lucide-react";
import { StatCard, LoadingBlock, ErrorBlock } from "@/components/lms/shared";
import { api, attColor, downloadCSV, useFetch, type Session, type CourseInfo, ASSESSMENT_TYPES } from "@/lib/lms";
import { useToast } from "@/hooks/use-toast";

interface EntryData {
  course: { id: string; code: string; name: string };
  assessment: { type: string; title: string; max: number };
  rows: { studentId: string; rollNo: string; name: string; section: string; marks: number | null }[];
  stats: { submitted: number; avg: number; highest: number; lowest: number };
}
interface SummaryData {
  course: { id: string; code: string; name: string };
  maxTotal: number;
  rows: { studentId: string; rollNo: string; name: string; section: string; perType: Record<string, number>; total: number; pct: number }[];
  classAvg: number;
  typeAverages: { type: string; title: string; avg: number; max: number }[];
}

export default function InternalMarks({ session }: { session: Session }) {
  const { toast } = useToast();
  const [courses, setCourses] = useState<CourseInfo[]>([]);
  const [courseId, setCourseId] = useState("");
  const [assessmentType, setAssessmentType] = useState("QUIZ_1");
  const [marks, setMarks] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    api<{ courses: CourseInfo[] }>("/api/courses", { session }).then((d) => {
      setCourses(d.courses);
      if (d.courses.length > 0) setCourseId((prev) => prev || d.courses[0].id);
    });
  }, [session]);

  const entryPath = courseId ? `/api/faculty/internal-marks?courseId=${courseId}&assessmentType=${assessmentType}` : null;
  const summaryPath = courseId ? `/api/faculty/internal-marks?courseId=${courseId}&view=summary` : null;
  const entry = useFetch<EntryData>(entryPath, session);
  const summary = useFetch<SummaryData>(summaryPath, session);

  // hydrate local editing state whenever loaded data changes
  useEffect(() => {
    if (entry.data) {
      const m: Record<string, string> = {};
      for (const r of entry.data.rows) m[r.studentId] = r.marks === null ? "" : String(r.marks);
      setMarks(m);
    }
  }, [entry.data]);

  const stats = useMemo(() => {
    const vals = Object.values(marks)
      .map((v) => parseFloat(v))
      .filter((v) => !Number.isNaN(v));
    const max = entry.data?.assessment.max ?? 10;
    return {
      entered: vals.length,
      avg: vals.length ? Math.round((vals.reduce((a, v) => a + v, 0) / vals.length) * 10) / 10 : 0,
      avgPct: vals.length ? Math.round((vals.reduce((a, v) => a + v, 0) / vals.length / max) * 1000) / 10 : 0,
      invalid: vals.some((v) => v < 0 || v > max),
    };
  }, [marks, entry.data]);

  const save = useCallback(async () => {
    if (!courseId || !entry.data) return;
    const records = entry.data.rows.map((r) => {
      const raw = marks[r.studentId]?.trim() ?? "";
      return { studentId: r.studentId, marks: raw === "" ? null : Number(raw) };
    });
    const invalid = records.find(
      (r) => r.marks !== null && (Number.isNaN(r.marks) || r.marks < 0 || r.marks > entry.data!.assessment.max)
    );
    if (invalid) {
      toast({ title: "Invalid marks", description: `All marks must be between 0 and ${entry.data.assessment.max}.`, variant: "destructive" });
      return;
    }
    setSaving(true);
    try {
      const res = await api<{ saved: number }>("/api/faculty/internal-marks", {
        method: "POST",
        session,
        body: JSON.stringify({ courseId, assessmentType, records }),
      });
      toast({ title: "Marks saved", description: `${res.saved} records saved for ${entry.data.assessment.title} · ${entry.data.course.code}` });
      summary.refetch?.();
      await entry.refetch?.();
    } catch (e) {
      toast({ title: "Save failed", description: (e as Error).message, variant: "destructive" });
    } finally {
      setSaving(false);
    }
  }, [courseId, entry, marks, session, summary, toast]);

  function exportSummaryCSV() {
    if (!summary.data) return;
    const d = summary.data;
    downloadCSV(`internal-summary-${d.course.code}.csv`, [
      ["Roll No", "Name", "Quiz 1 (10)", "Quiz 2 (10)", "Mid-Term (30)", "Assignment (20)", "Lab (25)", "Total (95)", "%"],
      ...d.rows.map((r) => [
        r.rollNo, r.name,
        r.perType["QUIZ_1"] ?? "", r.perType["QUIZ_2"] ?? "", r.perType["MID_TERM"] ?? "",
        r.perType["ASSIGNMENT"] ?? "", r.perType["LAB"] ?? "", r.total, `${r.pct}%`,
      ]),
    ]);
  }

  const course = courses.find((c) => c.id === courseId);

  return (
    <div className="space-y-4">
      <Card className="border-slate-200">
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <PenLine className="w-4 h-4 text-emerald-600" /> Internal Marks (Continuous Assessment)
          </CardTitle>
          <CardDescription>Enter or update marks per assessment. Totals are computed out of 95 (10+10+30+20+25).</CardDescription>
        </CardHeader>
        <CardContent className="flex flex-col sm:flex-row gap-3">
          <Select value={courseId} onValueChange={setCourseId}>
            <SelectTrigger className="w-full sm:w-64 bg-white"><SelectValue placeholder="Course" /></SelectTrigger>
            <SelectContent>
              {courses.map((c) => (
                <SelectItem key={c.id} value={c.id}>{c.code} — {c.name}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={assessmentType} onValueChange={setAssessmentType}>
            <SelectTrigger className="w-full sm:w-52 bg-white"><SelectValue placeholder="Assessment" /></SelectTrigger>
            <SelectContent>
              {ASSESSMENT_TYPES.map((a) => (
                <SelectItem key={a.value} value={a.value}>{a.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </CardContent>
      </Card>

      <Tabs defaultValue="entry">
        <TabsList>
          <TabsTrigger value="entry"><PenLine className="w-3.5 h-3.5 mr-1.5" />Enter Marks</TabsTrigger>
          <TabsTrigger value="summary"><ListChecks className="w-3.5 h-3.5 mr-1.5" />Internal Summary</TabsTrigger>
        </TabsList>

        <TabsContent value="entry" className="mt-4 space-y-4">
          {entry.loading ? <LoadingBlock /> : entry.error || !entry.data ? <ErrorBlock message={entry.error ?? "unknown"} /> : (
            <Card className="border-slate-200">
              <CardHeader className="pb-3">
                <div>
                  <CardTitle className="text-base">
                    {entry.data.assessment.title} · {entry.data.course.code} <span className="text-slate-400 font-normal">(max {entry.data.assessment.max})</span>
                  </CardTitle>
                  <CardDescription className="mt-1">Type marks directly — blank means not yet evaluated.</CardDescription>
                </div>
                <CardAction>
                  <Button onClick={save} disabled={saving || stats.invalid} className="bg-emerald-600 hover:bg-emerald-700">
                    {saving ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Save className="w-4 h-4 mr-2" />}
                    {saving ? "Saving…" : "Save marks"}
                  </Button>
                </CardAction>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-3 gap-3 mb-4">
                  <StatCard icon={PenLine} label="Entered" value={`${stats.entered}/${entry.data.rows.length}`} />
                  <StatCard icon={PenLine} label="Average" value={`${stats.avg} (${stats.avgPct}%)`} tone="teal" />
                  <StatCard icon={PenLine} label="Recorded avg (saved)" value={entry.data.stats.avg} sub={`high ${entry.data.stats.highest} · low ${entry.data.stats.lowest}`} tone="orange" />
                </div>
                {stats.invalid && (
                  <p className="mb-3 text-sm text-rose-600 bg-rose-50 border border-rose-200 rounded-md px-3 py-2">
                    Some marks are out of range (0–{entry.data.assessment.max}). Fix them before saving.
                  </p>
                )}
                <div className="rounded-lg border border-slate-200 overflow-hidden">
                  <div className="max-h-[26rem] overflow-y-auto">
                    <Table>
                      <TableHeader className="bg-slate-50 sticky top-0 z-10">
                        <TableRow>
                          <TableHead className="w-14">Roll</TableHead>
                          <TableHead>Student</TableHead>
                          <TableHead className="hidden md:table-cell">Sec</TableHead>
                          <TableHead className="w-32">Marks (/{entry.data.assessment.max})</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {entry.data.rows.map((r) => {
                          const v = marks[r.studentId] ?? "";
                          const bad = v !== "" && (Number(v) < 0 || Number(v) > entry.data!.assessment.max);
                          return (
                            <TableRow key={r.studentId}>
                              <TableCell className="font-mono text-xs text-slate-500">{r.rollNo.slice(-3)}</TableCell>
                              <TableCell className="font-medium text-sm">{r.name}</TableCell>
                              <TableCell className="hidden md:table-cell text-xs text-slate-500">{r.section}</TableCell>
                              <TableCell>
                                <Input
                                  type="number"
                                  min={0}
                                  max={entry.data!.assessment.max}
                                  step="0.5"
                                  value={v}
                                  onChange={(e) => setMarks((prev) => ({ ...prev, [r.studentId]: e.target.value }))}
                                  className={`h-8 text-sm ${bad ? "border-rose-400 focus-visible:ring-rose-300" : ""}`}
                                  placeholder="–"
                                />
                              </TableCell>
                            </TableRow>
                          );
                        })}
                      </TableBody>
                    </Table>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="summary" className="mt-4 space-y-4">
          {summary.loading ? <LoadingBlock /> : summary.error || !summary.data ? <ErrorBlock message={summary.error ?? "unknown"} /> : (
            <Card className="border-slate-200">
              <CardHeader className="pb-3">
                <div>
                  <CardTitle className="text-base">Internal Summary — {summary.data.course.code}: {summary.data.course.name}</CardTitle>
                  <CardDescription className="mt-1">
                    Class average: {summary.data.classAvg}% · {" "}
                    {course ? `Instructor: ${course.facultyName}` : ""}
                  </CardDescription>
                </div>
                <CardAction>
                  <Button variant="outline" size="sm" onClick={exportSummaryCSV} className="border-emerald-200 text-emerald-700 hover:bg-emerald-50">
                    <Download className="w-4 h-4 mr-1" /> CSV
                  </Button>
                </CardAction>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex flex-wrap gap-2">
                  {summary.data.typeAverages.map((t) => (
                    <Badge key={t.type} variant="outline" className="border-teal-200 bg-teal-50 text-teal-700">
                      {t.title}: avg {t.avg}/{t.max}
                    </Badge>
                  ))}
                </div>
                <div className="rounded-lg border border-slate-200 overflow-hidden">
                  <div className="max-h-[26rem] overflow-y-auto">
                    <Table>
                      <TableHeader className="bg-slate-50 sticky top-0 z-10">
                        <TableRow>
                          <TableHead className="w-14">Roll</TableHead>
                          <TableHead>Student</TableHead>
                          <TableHead className="text-center">Q1</TableHead>
                          <TableHead className="text-center">Q2</TableHead>
                          <TableHead className="text-center">Mid</TableHead>
                          <TableHead className="text-center">Asmt</TableHead>
                          <TableHead className="text-center">Lab</TableHead>
                          <TableHead className="text-center">Total/95</TableHead>
                          <TableHead className="w-36">%</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {summary.data.rows.map((r) => (
                          <TableRow key={r.studentId}>
                            <TableCell className="font-mono text-xs text-slate-500">{r.rollNo.slice(-3)}</TableCell>
                            <TableCell className="font-medium text-sm">{r.name}</TableCell>
                            <TableCell className="text-center text-sm">{r.perType["QUIZ_1"] ?? "–"}</TableCell>
                            <TableCell className="text-center text-sm">{r.perType["QUIZ_2"] ?? "–"}</TableCell>
                            <TableCell className="text-center text-sm">{r.perType["MID_TERM"] ?? "–"}</TableCell>
                            <TableCell className="text-center text-sm">{r.perType["ASSIGNMENT"] ?? "–"}</TableCell>
                            <TableCell className="text-center text-sm">{r.perType["LAB"] ?? "–"}</TableCell>
                            <TableCell className="text-center text-sm font-bold">{r.total}</TableCell>
                            <TableCell>
                              <div className="flex items-center gap-2">
                                <Progress
                                  value={r.pct}
                                  className={`h-2 flex-1 ${r.pct >= 70 ? "[&>div]:bg-emerald-500" : r.pct >= 55 ? "[&>div]:bg-amber-500" : "[&>div]:bg-rose-500"}`}
                                />
                                <span className={`text-xs font-bold w-12 text-right ${attColor(r.pct)}`}>{r.pct}%</span>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
