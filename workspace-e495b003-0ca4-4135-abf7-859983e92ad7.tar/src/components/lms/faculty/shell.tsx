"use client";

import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import {
  LayoutDashboard, CalendarCheck, FileBarChart2, PenLine, GraduationCap, Users, LogOut, GraduationCap as Logo,
} from "lucide-react";
import Overview from "@/components/lms/faculty/overview";
import AttendanceMarker from "@/components/lms/faculty/attendance";
import AttendanceReport from "@/components/lms/faculty/att-report";
import InternalMarks from "@/components/lms/faculty/internal-marks";
import ExamMarks from "@/components/lms/faculty/exam-marks";
import Students from "@/components/lms/faculty/students";
import type { Session } from "@/lib/lms";

export default function FacultyDashboard({ session, onLogout }: { session: Session; onLogout: () => void }) {
  const [tab, setTab] = useState("overview");
  const initials = session.user.name
    .split(" ")
    .filter((w) => /^[A-Za-z]/.test(w))
    .slice(-2)
    .map((w) => w[0])
    .join("")
    .toUpperCase();

  return (
    <div className="min-h-screen flex flex-col bg-slate-50">
      {/* header */}
      <header className="sticky top-0 z-30 bg-white/90 backdrop-blur border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-9 h-9 rounded-lg bg-emerald-600 flex items-center justify-center shrink-0">
              <Logo className="w-5 h-5 text-white" />
            </div>
            <div className="min-w-0">
              <p className="font-bold text-slate-800 leading-tight">EduTrack LMS</p>
              <p className="text-[11px] text-slate-500 truncate">Faculty Portal · CSE Department</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="hidden sm:block text-right">
              <p className="text-sm font-semibold text-slate-700 leading-tight">{session.user.name}</p>
              <p className="text-[11px] text-slate-500">{session.profile?.designation ?? "Faculty"} · {session.profile?.employeeId}</p>
            </div>
            <Avatar className="h-9 w-9">
              <AvatarFallback className="bg-emerald-100 text-emerald-700 text-sm font-bold">{initials}</AvatarFallback>
            </Avatar>
            <Button variant="outline" size="sm" onClick={onLogout} className="border-slate-200 text-slate-600">
              <LogOut className="w-4 h-4 mr-1" /> Logout
            </Button>
          </div>
        </div>
      </header>

      {/* content */}
      <main className="flex-1 w-full max-w-7xl mx-auto px-4 py-5">
        <Tabs value={tab} onValueChange={setTab}>
          <div className="overflow-x-auto pb-1 -mx-1 px-1">
            <TabsList className="inline-flex min-w-max h-10">
              <TabsTrigger value="overview"><LayoutDashboard className="w-4 h-4 mr-1.5" />Overview</TabsTrigger>
              <TabsTrigger value="attendance"><CalendarCheck className="w-4 h-4 mr-1.5" />Mark Attendance</TabsTrigger>
              <TabsTrigger value="att-report"><FileBarChart2 className="w-4 h-4 mr-1.5" />Attendance Report</TabsTrigger>
              <TabsTrigger value="internal"><PenLine className="w-4 h-4 mr-1.5" />Internal Marks</TabsTrigger>
              <TabsTrigger value="exams"><GraduationCap className="w-4 h-4 mr-1.5" />Exam Marks</TabsTrigger>
              <TabsTrigger value="students"><Users className="w-4 h-4 mr-1.5" />Students</TabsTrigger>
            </TabsList>
          </div>

          <TabsContent value="overview" className="mt-4">
            <Overview session={session} />
          </TabsContent>
          <TabsContent value="attendance" className="mt-4">
            <AttendanceMarker session={session} />
          </TabsContent>
          <TabsContent value="att-report" className="mt-4">
            <AttendanceReport session={session} />
          </TabsContent>
          <TabsContent value="internal" className="mt-4">
            <InternalMarks session={session} />
          </TabsContent>
          <TabsContent value="exams" className="mt-4">
            <ExamMarks session={session} />
          </TabsContent>
          <TabsContent value="students" className="mt-4">
            <Students session={session} />
          </TabsContent>
        </Tabs>
      </main>

      <footer className="mt-auto border-t border-slate-200 bg-white">
        <div className="max-w-7xl mx-auto px-4 py-3 flex flex-col sm:flex-row items-center justify-between gap-1 text-xs text-slate-400">
          <p>EduTrack LMS · Learning Management System</p>
          <p>Semester 5 · Academic Year 2026-27 · Computer Science & Engineering</p>
        </div>
      </footer>
    </div>
  );
}
