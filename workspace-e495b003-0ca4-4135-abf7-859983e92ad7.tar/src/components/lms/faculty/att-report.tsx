"use client";

import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardAction } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ReferenceLine } from "recharts";
import { Download, FileBarChart2 } from "lucide-react";
import { StatCard, LoadingBlock, ErrorBlock } from "@/components/lms/shared";
import { api, attColor, downloadCSV, useFetch, type Session, type CourseInfo } from "@/lib/lms";
import { AlertTriangle } from "lucide-react";

interface ReportData {
  course: { id: string; code: string; name: string };
  sessions: number;
  rows: {
    studentId: string; rollNo: string; name: string; section: string;
    present: number; late: number; absent: number; total: number; pct: number;
  }[];
  classAvg: number;
  sessionTrend: { date: string; label: string; pct: number }[];
  below75: number;
  totals: { present: number; late: number; absent: number };
}

export default function AttendanceReport({ session }: { session: Session }) {
  const [courses, setCourses] = useState<CourseInfo[]>([]);
  const [courseId, setCourseId] = useState<string>("");

  useEffect(() => {
    api<{ courses: CourseInfo[] }>("/api/courses", { session }).then((d) => {
      setCourses(d.courses);
      if (d.courses.length > 0) setCourseId((prev) => prev || d.courses[0].id);
    });
  }, [session]);

  const { data, loading, error } = useFetch<ReportData>(
    courseId ? `/api/faculty/attendance-report?courseId=${courseId}` : null,
    session
  );

  function exportCSV() {
    if (!data) return;
    downloadCSV(`attendance-report-${data.course.code}.csv`, [
      ["Roll No", "Name", "Section", "Present", "Late", "Absent", "Total Sessions", "Attendance %", "Status"],
      ...data.rows.map((r) => [
        r.rollNo, r.name, r.section, r.present, r.late, r.absent, r.sessions ?? data.sessions,
        `${r.pct}%`, r.pct >= 85 ? "Safe" : r.pct >= 75 ? "Warning" : "At Risk",
      ]),
      ["", "", "Class Average", data.totals.present, data.totals.late, data.totals.absent, data.sessions, `${data.classAvg}%`, ""],
    ]);
  }

  return (
    <div className="space-y-4">
      <Card className="border-slate-200">
        <CardHeader className="pb-3">
          <div>
            <CardTitle className="text-base flex items-center gap-2">
              <FileBarChart2 className="w-4 h-4 text-emerald-600" /> Attendance Report
            </CardTitle>
            <CardDescription className="mt-1">Per-student attendance summary with 75% eligibility benchmark</CardDescription>
          </div>
          <CardAction>
            <div className="flex items-center gap-2">
              <Select value={courseId} onValueChange={setCourseId}>
                <SelectTrigger className="w-56 bg-white"><SelectValue placeholder="Course" /></SelectTrigger>
                <SelectContent>
                  {courses.map((c) => (
                    <SelectItem key={c.id} value={c.id}>{c.code} — {c.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Button variant="outline" size="sm" onClick={exportCSV} className="border-emerald-200 text-emerald-700 hover:bg-emerald-50">
                <Download className="w-4 h-4 mr-1" /> CSV
              </Button>
            </div>
          </CardAction>
        </CardHeader>
      </Card>

      {loading ? <LoadingBlock /> : error || !data ? <ErrorBlock message={error ?? "unknown"} /> : (
        <div className="space-y-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <StatCard icon={FileBarChart2} label="Sessions held" value={data.sessions} />
            <StatCard icon={FileBarChart2} label="Class average" value={`${data.classAvg}%`} tone="teal" />
            <StatCard icon={AlertTriangle} label="Below 75%" value={data.below75} sub="exam eligibility risk" tone="rose" />
            <StatCard icon={FileBarChart2} label="Total absences" value={data.totals.absent} sub={`${data.totals.late} late arrivals`} tone="orange" />
          </div>

          <Card className="border-slate-200">
            <CardHeader className="pb-2">
              <CardTitle className="text-base">Session-wise Class Presence — {data.course.code}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-56">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={data.sessionTrend} margin={{ top: 5, right: 10, left: -18, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
                    <XAxis dataKey="label" tick={{ fontSize: 11 }} tickLine={false} axisLine={{ stroke: "#cbd5e1" }} />
                    <YAxis domain={[0, 100]} tick={{ fontSize: 11 }} tickLine={false} axisLine={false} unit="%" />
                    <Tooltip formatter={(v) => [`${v}%`, "Present"]} contentStyle={{ borderRadius: 8, fontSize: 12 }} />
                    <ReferenceLine y={75} stroke="#dc2626" strokeDasharray="4 4" label={{ value: "75%", fontSize: 10, fill: "#dc2626", position: "right" }} />
                    <Line type="monotone" dataKey="pct" stroke="#0d9488" strokeWidth={2.5} dot={{ r: 3, fill: "#0d9488" }} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          <Card className="border-slate-200">
            <CardHeader className="pb-2">
              <CardTitle className="text-base">Student-wise Attendance — {data.course.code}: {data.course.name}</CardTitle>
              <CardDescription>Sorted by roll number · includes late arrivals in attendance %</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="rounded-lg border border-slate-200 overflow-hidden">
                <div className="max-h-[30rem] overflow-y-auto">
                  <Table>
                    <TableHeader className="bg-slate-50 sticky top-0 z-10">
                      <TableRow>
                        <TableHead className="w-14">Roll</TableHead>
                        <TableHead>Student</TableHead>
                        <TableHead className="text-center">P</TableHead>
                        <TableHead className="text-center">L</TableHead>
                        <TableHead className="text-center">A</TableHead>
                        <TableHead className="w-44">Attendance</TableHead>
                        <TableHead className="text-right">Status</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {data.rows.map((r) => (
                        <TableRow key={r.studentId}>
                          <TableCell className="font-mono text-xs text-slate-500">{r.rollNo.slice(-3)}</TableCell>
                          <TableCell className="font-medium text-sm">{r.name}</TableCell>
                          <TableCell className="text-center text-sm text-emerald-600 font-medium">{r.present}</TableCell>
                          <TableCell className="text-center text-sm text-amber-600 font-medium">{r.late}</TableCell>
                          <TableCell className="text-center text-sm text-rose-600 font-medium">{r.absent}</TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <Progress
                                value={r.pct}
                                className={`h-2 flex-1 ${
                                  r.pct >= 85
                                    ? "[&>div]:bg-emerald-500"
                                    : r.pct >= 75
                                    ? "[&>div]:bg-amber-500"
                                    : "[&>div]:bg-rose-500"
                                }`}
                              />
                              <span className={`text-xs font-bold w-12 text-right ${attColor(r.pct)}`}>{r.pct}%</span>
                            </div>
                          </TableCell>
                          <TableCell className="text-right">
                            <Badge
                              variant="outline"
                              className={
                                r.pct >= 85
                                  ? "border-emerald-200 bg-emerald-50 text-emerald-700"
                                  : r.pct >= 75
                                  ? "border-amber-200 bg-amber-50 text-amber-700"
                                  : "border-rose-200 bg-rose-50 text-rose-700"
                              }
                            >
                              {r.pct >= 85 ? "Safe" : r.pct >= 75 ? "Warning" : "At Risk"}
                            </Badge>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}
