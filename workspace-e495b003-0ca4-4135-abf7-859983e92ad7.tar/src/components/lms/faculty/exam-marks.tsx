"use client";

import { useEffect, useMemo, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardAction } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from "recharts";
import { Plus, Save, Loader2, TrendingUp, GraduationCap, Search } from "lucide-react";
import { StatCard, LoadingBlock, ErrorBlock } from "@/components/lms/shared";
import { api, gradeBadgeClass, useFetch, type Session, type CourseInfo } from "@/lib/lms";
import { useToast } from "@/hooks/use-toast";

interface ExamRow {
  id: string; studentId: string; rollNo: string; name: string; section: string;
  courseId: string; courseCode: string; courseName: string; examType: string;
  semester: number; academicYear: string; maxMarks: number; marksObtained: number; grade: string;
}
interface ProgressData {
  semesters: { semester: number; academicYear: string; avgPct: number; sgpa: number; courses: number; bestSubject: string; bestPct: number; weakSubject: string; weakPct: number }[];
}

const EXAM_TYPES = [
  { value: "END_SEMESTER", label: "End Semester" },
  { value: "MID_SEMESTER", label: "Mid Semester" },
];

export default function ExamMarks({ session }: { session: Session }) {
  const { toast } = useToast();
  const [courses, setCourses] = useState<CourseInfo[]>([]);
  const [semester, setSemester] = useState("5");
  const [examType, setExamType] = useState("");
  const [search, setSearch] = useState("");

  const [dialogOpen, setDialogOpen] = useState(false);
  const [dCourseId, setDCourseId] = useState("");
  const [dExamType, setDExamType] = useState("END_SEMESTER");
  const [dYear, setDYear] = useState("2026-27");
  const [dSemester, setDSemester] = useState("5");
  const [dMax, setDMax] = useState("100");
  const [dMarks, setDMarks] = useState<Record<string, string>>({});
  const [dRoster, setDRoster] = useState<{ studentId: string; rollNo: string; name: string }[]>([]);
  const [dLoading, setDLoading] = useState(false);
  const [saving, setSaving] = useState(false);

  const query = useMemo(() => {
    const p = new URLSearchParams();
    if (semester) p.set("semester", semester);
    if (examType) p.set("examType", examType);
    return p.toString();
  }, [semester, examType]);

  const records = useFetch<{ rows: ExamRow[] }>(`/api/faculty/exam-marks?${query}`, session);
  const progress = useFetch<ProgressData>("/api/faculty/exam-progress", session);

  useEffect(() => {
    api<{ courses: CourseInfo[] }>("/api/courses", { session }).then((d) => {
      setCourses(d.courses);
      if (d.courses.length > 0) setDCourseId((prev) => prev || d.courses[0].id);
    });
  }, [session]);

  async function openDialog() {
    setDialogOpen(true);
    setDLoading(true);
    try {
      const d = await api<{ roster: { studentId: string; rollNo: string; name: string }[] }>(
        `/api/faculty/attendance?courseId=${dCourseId}&date=2026-11-04`,
        { session }
      );
      setDRoster(d.roster.map((r) => ({ studentId: r.studentId, rollNo: r.rollNo, name: r.name })));
      setDMarks({});
    } finally {
      setDLoading(false);
    }
  }

  async function saveExam() {
    const records = dRoster
      .map((r) => ({
        studentId: r.studentId,
        courseId: dCourseId,
        examType: dExamType,
        semester: Number(dSemester),
        academicYear: dYear,
        maxMarks: Number(dMax) || 100,
        marksObtained: dMarks[r.studentId] === undefined || dMarks[r.studentId] === "" ? NaN : Number(dMarks[r.studentId]),
      }))
      .filter((r) => !Number.isNaN(r.marksObtained));
    if (records.length === 0) {
      toast({ title: "Nothing to save", description: "Enter marks for at least one student.", variant: "destructive" });
      return;
    }
    const max = Number(dMax) || 100;
    if (records.some((r) => r.marksObtained < 0 || r.marksObtained > max)) {
      toast({ title: "Invalid marks", description: `Marks must be between 0 and ${max}.`, variant: "destructive" });
      return;
    }
    setSaving(true);
    try {
      const res = await api<{ saved: number }>("/api/faculty/exam-marks", {
        method: "POST",
        session,
        body: JSON.stringify({ records }),
      });
      toast({ title: "Exam marks recorded", description: `${res.saved} results saved. Grades computed automatically.` });
      setDialogOpen(false);
      recordsFn();
    } catch (e) {
      toast({ title: "Save failed", description: (e as Error).message, variant: "destructive" });
    } finally {
      setSaving(false);
    }
  }

  function recordsFn() {
    records.refetch();
    progress.refetch();
  }

  const filteredRows = (records.data?.rows ?? []).filter(
    (r) =>
      search === "" ||
      r.name.toLowerCase().includes(search.toLowerCase()) ||
      r.rollNo.toLowerCase().includes(search.toLowerCase()) ||
      r.courseCode.toLowerCase().includes(search.toLowerCase())
  );

  const avgOfRows = useMemo(() => {
    const rows = records.data?.rows ?? [];
    if (rows.length === 0) return { avg: 0, pass: 0, fail: 0 };
    const avg = Math.round((rows.reduce((a, r) => a + (r.marksObtained / r.maxMarks) * 100, 0) / rows.length) * 10) / 10;
    const fail = rows.filter((r) => r.grade === "F").length;
    return { avg, pass: rows.length - fail, fail };
  }, [records.data]);

  const progressChart = (progress.data?.semesters ?? []).map((s) => ({
    semester: `Sem ${s.semester}`,
    avgPct: s.avgPct,
    sgpa: s.sgpa,
  }));

  return (
    <div className="space-y-4">
      <Card className="border-slate-200">
        <CardHeader className="pb-3">
          <div>
            <CardTitle className="text-base flex items-center gap-2">
              <GraduationCap className="w-4 h-4 text-emerald-600" /> Past Exam Records & Progress
            </CardTitle>
            <CardDescription className="mt-1">Record exam marks (grades auto-computed) and track semester-wise progress.</CardDescription>
          </div>
          <CardAction>
            <Button onClick={openDialog} className="bg-emerald-600 hover:bg-emerald-700">
              <Plus className="w-4 h-4 mr-1.5" /> Record exam marks
            </Button>
          </CardAction>
        </CardHeader>
        <CardContent className="flex flex-col sm:flex-row gap-3">
          <Select value={semester} onValueChange={setSemester}>
            <SelectTrigger className="w-full sm:w-40 bg-white"><SelectValue placeholder="Semester" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All semesters</SelectItem>
              {[5, 4, 3, 2, 1].map((s) => (
                <SelectItem key={s} value={String(s)}>Semester {s}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={examType} onValueChange={setExamType}>
            <SelectTrigger className="w-full sm:w-48 bg-white"><SelectValue placeholder="All exam types" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All exam types</SelectItem>
              {EXAM_TYPES.map((t) => (
                <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <div className="relative flex-1">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-slate-400" />
            <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search student or course…" className="pl-8 bg-white" />
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <StatCard icon={GraduationCap} label="Records shown" value={filteredRows.length} />
        <StatCard icon={TrendingUp} label="Average score" value={`${avgOfRows.avg}%`} tone="teal" />
        <StatCard icon={GraduationCap} label="Passed" value={avgOfRows.pass} tone="emerald" />
        <StatCard icon={GraduationCap} label="Failed (F)" value={avgOfRows.fail} tone="rose" />
      </div>

      <div className="grid lg:grid-cols-2 gap-4">
        <Card className="border-slate-200">
          <CardHeader className="pb-2">
            <CardTitle className="text-base">Class Progress Across Semesters</CardTitle>
            <CardDescription>Average score % and SGPA per semester (all students)</CardDescription>
          </CardHeader>
          <CardContent>
            {progress.loading ? <Skeleton className="h-60 w-full" /> : (
              <div className="h-60">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={progressChart} margin={{ top: 5, right: 10, left: -18, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
                    <XAxis dataKey="semester" tick={{ fontSize: 11 }} tickLine={false} axisLine={{ stroke: "#cbd5e1" }} />
                    <YAxis yAxisId="left" domain={[40, 100]} tick={{ fontSize: 11 }} tickLine={false} axisLine={false} unit="%" />
                    <YAxis yAxisId="right" orientation="right" domain={[0, 10]} tick={{ fontSize: 11 }} tickLine={false} axisLine={false} />
                    <Tooltip contentStyle={{ borderRadius: 8, fontSize: 12 }} />
                    <Legend wrapperStyle={{ fontSize: 12 }} />
                    <Line yAxisId="left" type="monotone" dataKey="avgPct" name="Avg score %" stroke="#0d9488" strokeWidth={2.5} dot={{ r: 3 }} />
                    <Line yAxisId="right" type="monotone" dataKey="sgpa" name="SGPA (of 10)" stroke="#d97706" strokeWidth={2.5} dot={{ r: 3 }} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="border-slate-200">
          <CardHeader className="pb-2">
            <CardTitle className="text-base">Semester Insights</CardTitle>
            <CardDescription>Best & weakest subjects per semester</CardDescription>
          </CardHeader>
          <CardContent>
            {progress.loading ? <Skeleton className="h-60 w-full" /> : (
              <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
                {(progress.data?.semesters ?? []).slice().reverse().map((s) => (
                  <div key={s.semester} className="rounded-lg border border-slate-200 px-3 py-2.5 flex items-center justify-between gap-3">
                    <div className="min-w-0">
                      <p className="text-sm font-semibold text-slate-800">
                        Semester {s.semester} <span className="text-xs font-normal text-slate-400">{s.academicYear} · {s.courses} courses</span>
                      </p>
                      <p className="text-xs text-slate-500 truncate">
                        Best {s.bestSubject} ({s.bestPct}%) · Weak {s.weakSubject} ({s.weakPct}%)
                      </p>
                    </div>
                    <div className="text-right shrink-0">
                      <p className="text-sm font-bold text-emerald-700">{s.avgPct}%</p>
                      <p className="text-[11px] text-slate-400">SGPA {s.sgpa}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <Card className="border-slate-200">
        <CardHeader className="pb-2">
          <CardTitle className="text-base">Exam Results</CardTitle>
          <CardDescription>{filteredRows.length} records{search ? ` matching "${search}"` : ""}</CardDescription>
        </CardHeader>
        <CardContent>
          {records.loading ? <LoadingBlock height="h-72" /> : records.error ? <ErrorBlock message={records.error} /> : (
            <div className="rounded-lg border border-slate-200 overflow-hidden">
              <div className="max-h-[28rem] overflow-y-auto">
                <Table>
                  <TableHeader className="bg-slate-50 sticky top-0 z-10">
                    <TableRow>
                      <TableHead className="w-14">Roll</TableHead>
                      <TableHead>Student</TableHead>
                      <TableHead>Course</TableHead>
                      <TableHead className="hidden md:table-cell">Exam</TableHead>
                      <TableHead className="hidden sm:table-cell">Year</TableHead>
                      <TableHead className="text-center">Marks</TableHead>
                      <TableHead className="text-center">Grade</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredRows.slice(0, 400).map((r) => (
                      <TableRow key={r.id}>
                        <TableCell className="font-mono text-xs text-slate-500">{r.rollNo.slice(-3)}</TableCell>
                        <TableCell className="font-medium text-sm">{r.name}</TableCell>
                        <TableCell className="text-sm">
                          <span className="font-medium">{r.courseCode}</span>
                          <span className="hidden xl:inline text-slate-400"> · {r.courseName}</span>
                        </TableCell>
                        <TableCell className="hidden md:table-cell text-xs text-slate-500">
                          Sem {r.semester} · {r.examType === "END_SEMESTER" ? "End-Sem" : "Mid-Sem"}
                        </TableCell>
                        <TableCell className="hidden sm:table-cell text-xs text-slate-500">{r.academicYear}</TableCell>
                        <TableCell className="text-center text-sm font-semibold">
                          {r.marksObtained}
                          <span className="text-slate-400 font-normal">/{r.maxMarks}</span>
                        </TableCell>
                        <TableCell className="text-center">
                          <Badge className={`font-bold ${gradeBadgeClass(r.grade)}`}>{r.grade}</Badge>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* record exam marks dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[85vh] overflow-hidden flex flex-col">
          <DialogHeader>
            <DialogTitle>Record Exam Marks</DialogTitle>
            <DialogDescription>Grades (O, A+, A, B+…) are computed automatically from percentage.</DialogDescription>
          </DialogHeader>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 py-1">
            <div className="space-y-1.5">
              <label className="text-xs font-medium text-slate-500">Course</label>
              <Select value={dCourseId} onValueChange={setDCourseId}>
                <SelectTrigger className="bg-white"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {courses.map((c) => (
                    <SelectItem key={c.id} value={c.id}>{c.code}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <label className="text-xs font-medium text-slate-500">Exam type</label>
              <Select value={dExamType} onValueChange={setDExamType}>
                <SelectTrigger className="bg-white"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {EXAM_TYPES.map((t) => (
                    <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <label className="text-xs font-medium text-slate-500">Academic year</label>
              <Select value={dYear} onValueChange={setDYear}>
                <SelectTrigger className="bg-white"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {["2026-27", "2025-26", "2024-25"].map((y) => (
                    <SelectItem key={y} value={y}>{y}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div className="space-y-1.5">
                <label className="text-xs font-medium text-slate-500">Sem</label>
                <Select value={dSemester} onValueChange={setDSemester}>
                  <SelectTrigger className="bg-white"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {[5, 4, 3, 2, 1].map((s) => (
                      <SelectItem key={s} value={String(s)}>{s}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <label className="text-xs font-medium text-slate-500">Max</label>
                <Input type="number" value={dMax} onChange={(e) => setDMax(e.target.value)} className="bg-white" min={1} />
              </div>
            </div>
          </div>
          {dLoading ? (
            <Skeleton className="h-72 w-full" />
          ) : (
            <div className="rounded-lg border border-slate-200 overflow-y-auto max-h-80">
              <Table>
                <TableHeader className="bg-slate-50 sticky top-0">
                  <TableRow>
                    <TableHead className="w-14">Roll</TableHead>
                    <TableHead>Student</TableHead>
                    <TableHead className="w-32 text-right">Marks (/{Number(dMax) || 100})</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {dRoster.map((r) => (
                    <TableRow key={r.studentId}>
                      <TableCell className="font-mono text-xs text-slate-500">{r.rollNo.slice(-3)}</TableCell>
                      <TableCell className="font-medium text-sm">{r.name}</TableCell>
                      <TableCell>
                        <Input
                          type="number"
                          min={0}
                          max={Number(dMax) || 100}
                          step="0.5"
                          value={dMarks[r.studentId] ?? ""}
                          onChange={(e) => setDMarks((prev) => ({ ...prev, [r.studentId]: e.target.value }))}
                          className="h-8 text-sm"
                          placeholder="–"
                        />
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={saveExam} disabled={saving || dLoading} className="bg-emerald-600 hover:bg-emerald-700">
              {saving ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Save className="w-4 h-4 mr-2" />}
              Save results
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
