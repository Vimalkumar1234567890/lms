"use client";

import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import {
  ResponsiveContainer, AreaChart, Area, LineChart, Line, BarChart, Bar,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend, ReferenceLine, RadarChart,
  PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar,
} from "recharts";
import {
  LayoutDashboard, CalendarCheck, PenLine, TrendingUp, LogOut, GraduationCap as Logo,
  Percent, Award, Target, Medal, CheckCircle2, XCircle, Clock,
} from "lucide-react";
import { StatCard, LoadingBlock, ErrorBlock } from "@/components/lms/shared";
import { attColor, attLabel, gradeBadgeClass, useFetch, fmtDate, type Session } from "@/lib/lms";

/** Cumulative attendance % over an ordered list of sessions (pure, module-level). */
function cumulativeTrend(rows: { label: string; status: string }[]) {
  let hit = 0;
  return rows.map((r, i) => {
    if (r.status !== "ABSENT") hit++;
    return {
      label: r.label,
      pct: Math.round((hit / (i + 1)) * 1000) / 10,
      status: r.status,
    };
  });
}

interface DashboardData {
  profile: { name: string; email: string; rollNo: string; department: string; semester: number; section: string };
  courses: {
    courseId: string; code: string; name: string; credits: number; facultyName: string;
    present: number; late: number; absent: number; total: number; pct: number; classAvgPct: number;
  }[];
  internalMarks: {
    courseCode: string; courseName: string; total: number; max: number; pct: number;
    items: { type: string; title: string; marks: number; max: number; classAvg: number }[];
  }[];
  internalTotal: number;
  internalMax: number;
  internalPct: number;
  classInternalAvgPct: number;
  overallAttendancePct: number;
  exams: {
    semester: number; academicYear: string; examType: string; courseCode: string; courseName: string;
    marks: number; maxMarks: number; pct: number; grade: string; gradePoint: number;
  }[];
  semesters: { semester: number; academicYear: string; sgpa: number; avgPct: number }[];
  classSemesters: { semester: number; avgSgpa: number }[];
  rank: { position: number; of: number };
  recentAttendance: { date: string; label: string; courseCode: string; status: string; note: string | null }[];
}

export default function StudentDashboard({ session, onLogout }: { session: Session; onLogout: () => void }) {
  const [tab, setTab] = useState("overview");
  const { data, loading, error } = useFetch<DashboardData>("/api/student/dashboard", session);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="flex flex-col items-center gap-3">
          <Logo className="w-10 h-10 text-emerald-600" />
          <p className="text-sm text-slate-500">Loading your dashboard…</p>
        </div>
      </div>
    );
  }
  if (error || !data) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50 p-4">
        <ErrorBlock message={error ?? "unknown"} />
      </div>
    );
  }

  const initials = data.profile.name.split(" ").map((w) => w[0]).slice(0, 2).join("").toUpperCase();
  const overall = data.overallAttendancePct;
  const latestSem = data.semesters[data.semesters.length - 1];

  // personal attendance trend: cumulative % over recent sessions (last 24)
  const ordered = [...data.recentAttendance].reverse();
  const trendData = cumulativeTrend(ordered);

  // internal marks radar (student vs class avg per course)
  const radarData = data.internalMarks.map((c) => ({
    course: c.courseCode,
    you: c.pct,
    classAvg: data.classInternalAvgPct,
  }));

  // sgpa trend with class comparison
  const sgpaChart = data.semesters.map((s) => ({
    semester: `Sem ${s.semester}`,
    you: s.sgpa,
    classAvg: data.classSemesters.find((c) => c.semester === s.semester)?.avgSgpa ?? 0,
  }));

  // internal bar chart: per assessment type avg across your courses vs class
  const typeMap = new Map<string, { got: number; max: number; cls: number; clsMax: number; n: number }>();
  for (const c of data.internalMarks) {
    for (const it of c.items) {
      const t = typeMap.get(it.title) ?? { got: 0, max: 0, cls: 0, clsMax: 0, n: 0 };
      t.got += it.marks;
      t.max += it.max;
      t.cls += it.classAvg;
      t.clsMax += it.max;
      t.n++;
      typeMap.set(it.title, t);
    }
  }
  const assessChart = [...typeMap.entries()].map(([title, t]) => ({
    assessment: title,
    you: t.max ? Math.round((t.got / t.max) * 1000) / 10 : 0,
    classAvg: t.clsMax ? Math.round((t.cls / t.clsMax) * 1000) / 10 : 0,
  }));

  return (
    <div className="min-h-screen flex flex-col bg-slate-50">
      {/* header */}
      <header className="sticky top-0 z-30 bg-white/90 backdrop-blur border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-9 h-9 rounded-lg bg-emerald-600 flex items-center justify-center shrink-0">
              <Logo className="w-5 h-5 text-white" />
            </div>
            <div className="min-w-0">
              <p className="font-bold text-slate-800 leading-tight">EduTrack LMS</p>
              <p className="text-[11px] text-slate-500 truncate">
                {data.profile.rollNo} · Sem {data.profile.semester} · Section {data.profile.section}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="hidden sm:block text-right">
              <p className="text-sm font-semibold text-slate-700 leading-tight">{data.profile.name}</p>
              <p className="text-[11px] text-slate-500">{data.profile.email}</p>
            </div>
            <Avatar className="h-9 w-9">
              <AvatarFallback className="bg-emerald-100 text-emerald-700 text-sm font-bold">{initials}</AvatarFallback>
            </Avatar>
            <Button variant="outline" size="sm" onClick={onLogout} className="border-slate-200 text-slate-600">
              <LogOut className="w-4 h-4 mr-1" /> Logout
            </Button>
          </div>
        </div>
      </header>

      <main className="flex-1 w-full max-w-7xl mx-auto px-4 py-5">
        <Tabs value={tab} onValueChange={setTab}>
          <div className="overflow-x-auto pb-1 -mx-1 px-1">
            <TabsList className="inline-flex min-w-max h-10">
              <TabsTrigger value="overview"><LayoutDashboard className="w-4 h-4 mr-1.5" />Overview</TabsTrigger>
              <TabsTrigger value="attendance"><CalendarCheck className="w-4 h-4 mr-1.5" />My Attendance</TabsTrigger>
              <TabsTrigger value="marks"><PenLine className="w-4 h-4 mr-1.5" />My Marks</TabsTrigger>
              <TabsTrigger value="progress"><TrendingUp className="w-4 h-4 mr-1.5" />My Progress</TabsTrigger>
            </TabsList>
          </div>

          {/* ================= OVERVIEW ================= */}
          <TabsContent value="overview" className="mt-4 space-y-5">
            <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-3">
              <StatCard icon={Percent} label="Attendance" value={`${overall}%`} sub={attLabel(overall)} tone={overall >= 85 ? "emerald" : overall >= 75 ? "amber" : "rose"} />
              <StatCard icon={PenLine} label="Internal score" value={`${data.internalPct}%`} sub={`${data.internalTotal}/${data.internalMax} marks`} tone="orange" />
              <StatCard icon={Award} label="Current SGPA" value={latestSem?.sgpa ?? "—"} sub="Semester 5 mid-sem" tone="teal" />
              <StatCard icon={Medal} label="Class rank" value={`#${data.rank.position}`} sub={`of ${data.rank.of} students`} />
              <StatCard icon={Target} label="Class avg internal" value={`${data.classInternalAvgPct}%`} sub="vs your internal %" tone="teal" />
              <StatCard icon={CalendarCheck} label="Classes attended" value={data.courses.reduce((a, c) => a + c.present + c.late, 0)} sub={`of ${data.courses.reduce((a, c) => a + c.total, 0)} held`} tone="emerald" />
            </div>

            <div className="grid lg:grid-cols-5 gap-4">
              <Card className="lg:col-span-3 border-slate-200">
                <CardHeader className="pb-2">
                  <CardTitle className="text-base">My Attendance Trend</CardTitle>
                  <CardDescription>Cumulative attendance % over recent class sessions (all courses combined)</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-60">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={trendData} margin={{ top: 5, right: 10, left: -18, bottom: 0 }}>
                        <defs>
                          <linearGradient id="myAtt" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="0%" stopColor="#059669" stopOpacity={0.35} />
                            <stop offset="100%" stopColor="#059669" stopOpacity={0.02} />
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
                        <XAxis dataKey="label" tick={{ fontSize: 10 }} tickLine={false} axisLine={{ stroke: "#cbd5e1" }} interval={3} />
                        <YAxis domain={[0, 100]} tick={{ fontSize: 11 }} tickLine={false} axisLine={false} unit="%" />
                        <Tooltip formatter={(v) => [`${v}%`, "Cumulative"]} contentStyle={{ borderRadius: 8, fontSize: 12 }} />
                        <ReferenceLine y={75} stroke="#dc2626" strokeDasharray="4 4" />
                        <Area type="monotone" dataKey="pct" stroke="#059669" strokeWidth={2.5} fill="url(#myAtt)" />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>

              <Card className="lg:col-span-2 border-slate-200">
                <CardHeader className="pb-2">
                  <CardTitle className="text-base">Internal Marks — You vs Class</CardTitle>
                  <CardDescription>Average score % per assessment type</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-60">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={assessChart} margin={{ top: 5, right: 10, left: -20, bottom: 0 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
                        <XAxis dataKey="assessment" tick={{ fontSize: 10 }} tickLine={false} axisLine={{ stroke: "#cbd5e1" }} />
                        <YAxis domain={[0, 100]} tick={{ fontSize: 11 }} tickLine={false} axisLine={false} unit="%" />
                        <Tooltip formatter={(v) => [`${v}%`, ""]} contentStyle={{ borderRadius: 8, fontSize: 12 }} />
                        <Legend wrapperStyle={{ fontSize: 11 }} />
                        <Bar dataKey="you" name="You" fill="#059669" radius={[5, 5, 0, 0]} maxBarSize={26} />
                        <Bar dataKey="classAvg" name="Class avg" fill="#d97706" radius={[5, 5, 0, 0]} maxBarSize={26} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card className="border-slate-200">
              <CardHeader className="pb-2">
                <CardTitle className="text-base">Course Snapshot</CardTitle>
              </CardHeader>
              <CardContent className="grid sm:grid-cols-2 xl:grid-cols-3 gap-3">
                {data.courses.map((c) => (
                  <div key={c.courseId} className="rounded-xl border border-slate-200 p-3.5 hover:border-emerald-300 transition-colors">
                    <div className="flex items-start justify-between">
                      <div className="min-w-0">
                        <p className="font-semibold text-sm text-slate-800">{c.code}</p>
                        <p className="text-xs text-slate-500 truncate">{c.name}</p>
                      </div>
                      <span className={`text-sm font-bold ${attColor(c.pct)}`}>{c.pct}%</span>
                    </div>
                    <Progress
                      value={c.pct}
                      className={`mt-2.5 h-1.5 ${c.pct >= 85 ? "[&>div]:bg-emerald-500" : c.pct >= 75 ? "[&>div]:bg-amber-500" : "[&>div]:bg-rose-500"}`}
                    />
                    <p className="text-[11px] text-slate-400 mt-2">
                      {c.facultyName} · class avg {c.classAvgPct}% · {c.absent} absence{c.absent === 1 ? "" : "s"}
                    </p>
                  </div>
                ))}
              </CardContent>
            </Card>
          </TabsContent>

          {/* ================= ATTENDANCE ================= */}
          <TabsContent value="attendance" className="mt-4 space-y-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <StatCard icon={Percent} label="Overall" value={`${overall}%`} sub={attLabel(overall)} tone={overall >= 85 ? "emerald" : overall >= 75 ? "amber" : "rose"} />
              <StatCard icon={CheckCircle2} label="Present" value={data.courses.reduce((a, c) => a + c.present, 0)} tone="emerald" />
              <StatCard icon={Clock} label="Late" value={data.courses.reduce((a, c) => a + c.late, 0)} tone="orange" />
              <StatCard icon={XCircle} label="Absent" value={data.courses.reduce((a, c) => a + c.absent, 0)} tone="rose" />
            </div>

            <Card className="border-slate-200">
              <CardHeader className="pb-2">
                <CardTitle className="text-base">Course-wise Attendance</CardTitle>
                <CardDescription>75% is the minimum required for exam eligibility</CardDescription>
              </CardHeader>
              <CardContent className="grid sm:grid-cols-2 xl:grid-cols-3 gap-3">
                {data.courses.map((c) => (
                  <div key={c.courseId} className="rounded-xl border border-slate-200 p-4">
                    <div className="flex items-center justify-between">
                      <p className="font-semibold text-sm">{c.code}</p>
                      <Badge
                        variant="outline"
                        className={
                          c.pct >= 85
                            ? "border-emerald-200 bg-emerald-50 text-emerald-700"
                            : c.pct >= 75
                            ? "border-amber-200 bg-amber-50 text-amber-700"
                            : "border-rose-200 bg-rose-50 text-rose-700"
                        }
                      >
                        {attLabel(c.pct)}
                      </Badge>
                    </div>
                    <p className="text-xs text-slate-500 mb-2 truncate">{c.name}</p>
                    <div className="flex items-end gap-2">
                      <span className={`text-2xl font-bold ${attColor(c.pct)}`}>{c.pct}%</span>
                      <span className="text-xs text-slate-400 mb-1">class avg {c.classAvgPct}%</span>
                    </div>
                    <Progress
                      value={c.pct}
                      className={`mt-2 h-2 ${c.pct >= 85 ? "[&>div]:bg-emerald-500" : c.pct >= 75 ? "[&>div]:bg-amber-500" : "[&>div]:bg-rose-500"}`}
                    />
                    <div className="mt-2 flex gap-3 text-xs text-slate-500">
                      <span className="text-emerald-600">{c.present} present</span>
                      <span className="text-amber-600">{c.late} late</span>
                      <span className="text-rose-600">{c.absent} absent</span>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card className="border-slate-200">
              <CardHeader className="pb-2">
                <CardTitle className="text-base">Recent Sessions</CardTitle>
                <CardDescription>Last 30 class sessions across your courses</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="rounded-lg border border-slate-200 overflow-hidden">
                  <div className="max-h-72 overflow-y-auto">
                    <Table>
                      <TableHeader className="bg-slate-50 sticky top-0 z-10">
                        <TableRow>
                          <TableHead>Date</TableHead>
                          <TableHead>Course</TableHead>
                          <TableHead className="text-center">Status</TableHead>
                          <TableHead className="hidden sm:table-cell">Note</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {data.recentAttendance.map((r, i) => (
                          <TableRow key={i}>
                            <TableCell className="text-sm">{fmtDate(r.date)}</TableCell>
                            <TableCell className="text-sm font-medium">{r.courseCode}</TableCell>
                            <TableCell className="text-center">
                              <Badge
                                variant="outline"
                                className={
                                  r.status === "PRESENT"
                                    ? "border-emerald-200 bg-emerald-50 text-emerald-700"
                                    : r.status === "LATE"
                                    ? "border-amber-200 bg-amber-50 text-amber-700"
                                    : "border-rose-200 bg-rose-50 text-rose-700"
                                }
                              >
                                {r.status}
                              </Badge>
                            </TableCell>
                            <TableCell className="hidden sm:table-cell text-xs text-slate-400">{r.note ?? "—"}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* ================= MARKS ================= */}
          <TabsContent value="marks" className="mt-4 space-y-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <StatCard icon={PenLine} label="Internal total" value={`${data.internalTotal}/${data.internalMax}`} sub={`${data.internalPct}%`} tone="orange" />
              <StatCard icon={Target} label="Class avg internal" value={`${data.classInternalAvgPct}%`} tone="teal" />
              <StatCard icon={Award} label="Mid-sem SGPA" value={latestSem?.sgpa ?? "—"} sub="semester 5" />
              <StatCard icon={Medal} label="Rank" value={`#${data.rank.position}`} sub={`of ${data.rank.of}`} />
            </div>

            <Card className="border-slate-200">
              <CardHeader className="pb-2">
                <CardTitle className="text-base">Internal Marks — Semester 5</CardTitle>
                <CardDescription>Your continuous assessment performance against class averages</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="rounded-lg border border-slate-200 overflow-hidden">
                  <div className="max-h-96 overflow-y-auto">
                    <Table>
                      <TableHeader className="bg-slate-50 sticky top-0 z-10">
                        <TableRow>
                          <TableHead>Course</TableHead>
                          <TableHead className="text-center">Quiz 1 /10</TableHead>
                          <TableHead className="text-center">Quiz 2 /10</TableHead>
                          <TableHead className="text-center">Mid-sem /30</TableHead>
                          <TableHead className="text-center">Assignment /20</TableHead>
                          <TableHead className="text-center">Lab /25</TableHead>
                          <TableHead className="text-center">Total /95</TableHead>
                          <TableHead className="w-28">%</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {data.internalMarks.map((c) => (
                          <TableRow key={c.courseCode}>
                            <TableCell>
                              <p className="text-sm font-medium">{c.courseCode}</p>
                              <p className="text-[11px] text-slate-400 truncate max-w-40">{c.courseName}</p>
                            </TableCell>
                            {["QUIZ_1", "QUIZ_2", "MID_TERM", "ASSIGNMENT", "LAB"].map((t) => {
                              const item = c.items.find((i) => i.type === t);
                              return (
                                <TableCell key={t} className="text-center text-sm">
                                  {item ? (
                                    <span className={item.marks / item.max >= 0.7 ? "text-emerald-600 font-medium" : item.marks / item.max >= 0.5 ? "text-amber-600 font-medium" : "text-rose-600 font-medium"}>
                                      {item.marks}
                                    </span>
                                  ) : (
                                    <span className="text-slate-300">–</span>
                                  )}
                                  {item && <span className="block text-[10px] text-slate-400">avg {item.classAvg}</span>}
                                </TableCell>
                              );
                            })}
                            <TableCell className="text-center text-sm font-bold">{c.total}</TableCell>
                            <TableCell>
                              <div className="flex items-center gap-1.5">
                                <Progress
                                  value={c.pct}
                                  className={`h-1.5 flex-1 ${c.pct >= 70 ? "[&>div]:bg-emerald-500" : c.pct >= 55 ? "[&>div]:bg-amber-500" : "[&>div]:bg-rose-500"}`}
                                />
                                <span className={`text-xs font-bold w-10 text-right ${attColor(c.pct)}`}>{c.pct}%</span>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-slate-200">
              <CardHeader className="pb-2">
                <CardTitle className="text-base">Exam History</CardTitle>
                <CardDescription>All recorded exam results since Semester 1</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="rounded-lg border border-slate-200 overflow-hidden">
                  <div className="max-h-96 overflow-y-auto">
                    <Table>
                      <TableHeader className="bg-slate-50 sticky top-0 z-10">
                        <TableRow>
                          <TableHead>Sem</TableHead>
                          <TableHead>Course</TableHead>
                          <TableHead className="hidden sm:table-cell">Type</TableHead>
                          <TableHead className="hidden md:table-cell">Year</TableHead>
                          <TableHead className="text-center">Marks</TableHead>
                          <TableHead className="text-center">%</TableHead>
                          <TableHead className="text-center">Grade</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {[...data.exams].reverse().map((e, i) => (
                          <TableRow key={i}>
                            <TableCell className="text-sm">{e.semester}</TableCell>
                            <TableCell className="text-sm font-medium">{e.courseCode}<span className="hidden xl:inline text-slate-400 font-normal"> · {e.courseName}</span></TableCell>
                            <TableCell className="hidden sm:table-cell text-xs text-slate-500">{e.examType === "END_SEMESTER" ? "End-Sem" : "Mid-Sem"}</TableCell>
                            <TableCell className="hidden md:table-cell text-xs text-slate-500">{e.academicYear}</TableCell>
                            <TableCell className="text-center text-sm font-semibold">{e.marks}/{e.maxMarks}</TableCell>
                            <TableCell className={`text-center text-sm font-medium ${attColor(e.pct)}`}>{e.pct}%</TableCell>
                            <TableCell className="text-center">
                              <Badge className={`font-bold ${gradeBadgeClass(e.grade)}`}>{e.grade}</Badge>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* ================= PROGRESS ================= */}
          <TabsContent value="progress" className="mt-4 space-y-4">
            <div className="grid lg:grid-cols-3 gap-4">
              <Card className="lg:col-span-2 border-slate-200">
                <CardHeader className="pb-2">
                  <CardTitle className="text-base">SGPA Journey</CardTitle>
                  <CardDescription>Your SGPA vs class average across semesters (Sem 5 = mid-sem)</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-64">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={sgpaChart} margin={{ top: 5, right: 10, left: -18, bottom: 0 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
                        <XAxis dataKey="semester" tick={{ fontSize: 11 }} tickLine={false} axisLine={{ stroke: "#cbd5e1" }} />
                        <YAxis domain={[0, 10]} tick={{ fontSize: 11 }} tickLine={false} axisLine={false} />
                        <Tooltip contentStyle={{ borderRadius: 8, fontSize: 12 }} />
                        <Legend wrapperStyle={{ fontSize: 11 }} />
                        <Line type="monotone" dataKey="you" name="You" stroke="#059669" strokeWidth={3} dot={{ r: 4 }} />
                        <Line type="monotone" dataKey="classAvg" name="Class avg" stroke="#d97706" strokeWidth={2} strokeDasharray="6 3" dot={{ r: 3 }} />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-slate-200">
                <CardHeader className="pb-2">
                  <CardTitle className="text-base">Strengths by Course</CardTitle>
                  <CardDescription>Internal % vs class average</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-64">
                    <ResponsiveContainer width="100%" height="100%">
                      <RadarChart data={radarData} outerRadius="72%">
                        <PolarGrid stroke="#e2e8f0" />
                        <PolarAngleAxis dataKey="course" tick={{ fontSize: 10 }} />
                        <PolarRadiusAxis domain={[0, 100]} tick={{ fontSize: 9 }} />
                        <Radar name="You" dataKey="you" stroke="#059669" fill="#059669" fillOpacity={0.35} />
                        <Radar name="Class" dataKey="classAvg" stroke="#d97706" fill="#d97706" fillOpacity={0.08} />
                        <Legend wrapperStyle={{ fontSize: 11 }} />
                        <Tooltip contentStyle={{ borderRadius: 8, fontSize: 12 }} formatter={(v) => [`${v}%`, ""]} />
                      </RadarChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card className="border-slate-200">
              <CardHeader className="pb-2">
                <CardTitle className="text-base">Semester Report Cards</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid sm:grid-cols-2 xl:grid-cols-5 gap-3">
                  {data.semesters.slice().reverse().map((s) => (
                    <div key={s.semester} className="rounded-xl border border-slate-200 p-4">
                      <div className="flex items-center justify-between">
                        <p className="font-semibold text-sm">Semester {s.semester}</p>
                        <Badge className="bg-emerald-100 text-emerald-700 hover:bg-emerald-100">{s.sgpa} SGPA</Badge>
                      </div>
                      <p className="text-[11px] text-slate-400 mb-2">{s.academicYear}</p>
                      <div className="flex items-end gap-2">
                        <span className="text-xl font-bold text-slate-700">{s.avgPct}%</span>
                        <span className="text-[11px] text-slate-400 mb-1">avg score</span>
                      </div>
                      <Progress value={s.avgPct} className="mt-2 h-1.5 [&>div]:bg-teal-500" />
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>

      <footer className="mt-auto border-t border-slate-200 bg-white">
        <div className="max-w-7xl mx-auto px-4 py-3 flex flex-col sm:flex-row items-center justify-between gap-1 text-xs text-slate-400">
          <p>EduTrack LMS · Learning Management System</p>
          <p>{data.profile.department} · Semester {data.profile.semester} · 2026-27</p>
        </div>
      </footer>
    </div>
  );
}
