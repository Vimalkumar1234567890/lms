"use client";

import { useState, useEffect } from "react";

// ---------- session ----------
export interface Session {
  token: string;
  user: { id: string; name: string; email: string; role: "FACULTY" | "STUDENT" };
  profile: {
    employeeId?: string;
    department?: string;
    designation?: string;
    phone?: string;
    rollNo?: string;
    semester?: number;
    section?: string;
  } | null;
}

const SESSION_KEY = "lms_session_v1";

export function loadSession(): Session | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = localStorage.getItem(SESSION_KEY);
    return raw ? (JSON.parse(raw) as Session) : null;
  } catch {
    return null;
  }
}

export function saveSession(s: Session) {
  localStorage.setItem(SESSION_KEY, JSON.stringify(s));
}

export function clearSession() {
  localStorage.removeItem(SESSION_KEY);
}

// ---------- api helper ----------
export async function api<T>(path: string, init?: RequestInit & { session?: Session | null }): Promise<T> {
  const headers: Record<string, string> = { "Content-Type": "application/json" };
  if (init?.session) headers["x-user-id"] = init.session.token;
  const res = await fetch(path, { ...init, headers: { ...headers, ...(init?.headers as object) } });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error((data as { error?: string }).error ?? `Request failed (${res.status})`);
  return data as T;
}

// ---------- shared types ----------
export interface CourseInfo {
  id: string;
  code: string;
  name: string;
  credits: number;
  semester: number;
  facultyName: string;
  facultyId: string | null;
}

export interface LoginResponse {
  token: string;
  user: Session["user"];
  profile: Session["profile"];
}

// ---------- utils ----------
export const attColor = (pct: number) =>
  pct >= 85 ? "text-emerald-600" : pct >= 75 ? "text-amber-600" : "text-rose-600";

export const attBg = (pct: number) =>
  pct >= 85 ? "bg-emerald-500" : pct >= 75 ? "bg-amber-500" : "bg-rose-500";

export const attLabel = (pct: number) =>
  pct >= 85 ? "Safe" : pct >= 75 ? "Warning" : "At Risk";

export function gradeBadgeClass(grade: string) {
  if (grade === "O") return "bg-emerald-100 text-emerald-800";
  if (grade === "A+") return "bg-teal-100 text-teal-800";
  if (grade === "A") return "bg-green-100 text-green-800";
  if (grade === "B+") return "bg-amber-100 text-amber-800";
  if (grade === "B") return "bg-orange-100 text-orange-800";
  if (grade === "C") return "bg-rose-100 text-rose-700";
  return "bg-rose-200 text-rose-900";
}

export const fmtDate = (iso: string) => {
  const dt = new Date(iso + "T00:00:00Z");
  return dt.toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric", timeZone: "UTC" });
};

export const todayISO = () => {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")}`;
};

export const ASSESSMENT_TYPES = [
  { value: "QUIZ_1", label: "Quiz 1 (10)" },
  { value: "QUIZ_2", label: "Quiz 2 (10)" },
  { value: "MID_TERM", label: "Mid-Term (30)" },
  { value: "ASSIGNMENT", label: "Assignment (20)" },
  { value: "LAB", label: "Lab Evaluation (25)" },
];

export const CHART_COLORS = ["#059669", "#0d9488", "#d97706", "#dc2626", "#7c3aed", "#65a30d"];

export function downloadCSV(filename: string, rows: (string | number)[][]) {
  const csv = rows
    .map((r) => r.map((c) => `"${String(c).replace(/"/g, '""')}"`).join(","))
    .join("\n");
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

/** Small hook for fetching data with loading/error state. */
export function useFetch<T>(path: string | null, session: Session | null) {
  const [data, setData] = useState<T | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [tick, setTick] = useState(0);

  useEffect(() => {
    if (!path || !session) return;
    let cancelled = false;
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setLoading(true);
    setError(null);
    api<T>(path, { session })
      .then((d) => {
        if (!cancelled) {
          setData(d);
          setLoading(false);
        }
      })
      .catch((e: Error) => {
        if (!cancelled) {
          setError(e.message);
          setLoading(false);
        }
      });
    return () => {
      cancelled = true;
    };
  }, [path, session, tick]);

  const refetch = () => setTick((t) => t + 1);
  return { data, loading, error, setData, refetch };
}
