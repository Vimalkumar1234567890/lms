import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { User, FacultyProfile, StudentProfile } from "@prisma/client";

export type SessionUser = User & {
  facultyProfile: FacultyProfile | null;
  studentProfile: StudentProfile | null;
};

/**
 * Lightweight session auth: the client sends the user id (returned by login)
 * in the `x-user-id` header. We validate it against the database and enforce
 * the expected role.
 */
export async function getSessionUser(
  req: NextRequest,
  expectedRole?: "FACULTY" | "STUDENT"
): Promise<SessionUser | null> {
  const userId = req.headers.get("x-user-id");
  if (!userId) return null;
  const user = await db.user.findUnique({
    where: { id: userId },
    include: { facultyProfile: true, studentProfile: true },
  });
  if (!user) return null;
  if (expectedRole && user.role !== expectedRole) return null;
  return user;
}

export function unauthorized(msg = "Unauthorized") {
  return Response.json({ error: msg }, { status: 401 });
}

export function badRequest(msg: string) {
  return Response.json({ error: msg }, { status: 400 });
}
