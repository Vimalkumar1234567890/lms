import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { badRequest } from "@/lib/auth";
import * as crypto from "crypto";

const hash = (pw: string) => crypto.createHash("sha256").update(`lms::${pw}`).digest("hex");

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const email = String(body.email ?? "").trim().toLowerCase();
    const password = String(body.password ?? "");
    if (!email || !password) return badRequest("Email and password are required");

    const user = await db.user.findUnique({
      where: { email },
      include: { facultyProfile: true, studentProfile: true },
    });
    if (!user || user.password !== hash(password)) {
      return Response.json({ error: "Invalid email or password" }, { status: 401 });
    }

    const profile =
      user.role === "FACULTY"
        ? user.facultyProfile
          ? {
              employeeId: user.facultyProfile.employeeId,
              department: user.facultyProfile.department,
              designation: user.facultyProfile.designation,
              phone: user.facultyProfile.phone,
            }
          : null
        : user.studentProfile
        ? {
            rollNo: user.studentProfile.rollNo,
            department: user.studentProfile.department,
            semester: user.studentProfile.semester,
            section: user.studentProfile.section,
            phone: user.studentProfile.phone,
          }
        : null;

    return Response.json({
      token: user.id,
      user: { id: user.id, name: user.name, email: user.email, role: user.role },
      profile,
    });
  } catch {
    return badRequest("Invalid request");
  }
}
