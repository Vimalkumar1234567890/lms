import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { getSessionUser, unauthorized } from "@/lib/auth";

/** Everything the student dashboard needs, in one payload. */
export async function GET(req: NextRequest) {
  const user = await getSessionUser(req, "STUDENT");
  if (!user) return unauthorized();
  const student = user.studentProfile;
  if (!student) return Response.json({ error: "Student profile missing" }, { status: 400 });

  const currentCourses = await db.course.findMany({
    where: { semester: 5 },
    orderBy: { code: "asc" },
    include: { faculty: { include: { user: true } } },
  });
  const courseIds = currentCourses.map((c) => c.id);

  const [allAttendance, myInternal, classInternal, myExams, classExams, enrolled] = await Promise.all([
    db.attendance.findMany({ where: { courseId: { in: courseIds } }, orderBy: { date: "asc" } }),
    db.internalMark.findMany({ where: { studentId: student.id } }),
    db.internalMark.findMany({ where: { courseId: { in: courseIds } } }),
    db.examResult.findMany({
      where: { studentId: student.id },
      include: { course: true },
      orderBy: [{ semester: "asc" }, { course: { code: "asc" } }],
    }),
    db.examResult.findMany({ include: { course: true } }),
    db.enrollment.findMany({ where: { studentId: student.id } }),
  ]);

  const enrolledIds = new Set(enrolled.map((e) => e.courseId));
  const myAttendance = allAttendance.filter((a) => a.studentId === student.id);

  // ---- courses with attendance ----
  const attByCourse = new Map<string, { present: number; late: number; absent: number }>();
  const classAttByCourse = new Map<string, { present: number; total: number }>();
  for (const a of allAttendance) {
    const c = classAttByCourse.get(a.courseId) ?? { present: 0, total: 0 };
    c.total++;
    if (a.status !== "ABSENT") c.present++;
    classAttByCourse.set(a.courseId, c);
  }
  for (const a of myAttendance) {
    const t = attByCourse.get(a.courseId) ?? { present: 0, late: 0, absent: 0 };
    if (a.status === "PRESENT") t.present++;
    else if (a.status === "LATE") t.late++;
    else t.absent++;
    attByCourse.set(a.courseId, t);
  }

  const courses = currentCourses
    .filter((c) => enrolledIds.has(c.id))
    .map((c) => {
      const t = attByCourse.get(c.id) ?? { present: 0, late: 0, absent: 0 };
      const total = t.present + t.late + t.absent;
      const cls = classAttByCourse.get(c.id);
      return {
        courseId: c.id,
        code: c.code,
        name: c.name,
        credits: c.credits,
        facultyName: c.faculty?.user.name ?? "Staff",
        present: t.present,
        late: t.late,
        absent: t.absent,
        total,
        pct: total ? Math.round(((t.present + t.late) / total) * 1000) / 10 : 0,
        classAvgPct: cls && cls.total ? Math.round((cls.present / cls.total) * 1000) / 10 : 0,
      };
    });

  // ---- internal marks ----
  const ASSESS_ORDER = ["QUIZ_1", "QUIZ_2", "MID_TERM", "ASSIGNMENT", "LAB"];
  const myIntByCourse = new Map<string, Map<string, { marks: number; max: number; title: string }>>();
  const classIntByCourseType = new Map<string, { sum: number; count: number; max: number }>();
  for (const m of classInternal) {
    const key = `${m.courseId}:${m.assessmentType}`;
    const t = classIntByCourseType.get(key) ?? { sum: 0, count: 0, max: m.maxMarks };
    t.sum += m.marksObtained;
    t.count++;
    classIntByCourseType.set(key, t);
  }
  for (const m of myInternal) {
    const byType = myIntByCourse.get(m.courseId) ?? new Map();
    byType.set(m.assessmentType, { marks: m.marksObtained, max: m.maxMarks, title: m.title });
    myIntByCourse.set(m.courseId, byType);
  }

  let internalTotal = 0;
  let internalMax = 0;
  const internalMarks = courses.map((c) => {
    const byType = myIntByCourse.get(c.courseId) ?? new Map();
    const items = ASSESS_ORDER.filter((t) => byType.has(t)).map((t) => {
      const v = byType.get(t)!;
      const cls = classIntByCourseType.get(`${c.courseId}:${t}`);
      internalTotal += v.marks;
      internalMax += v.max;
      return {
        type: t,
        title: v.title,
        marks: v.marks,
        max: v.max,
        classAvg: cls && cls.count ? Math.round((cls.sum / cls.count) * 10) / 10 : 0,
      };
    });
    const got = items.reduce((a, i) => a + i.marks, 0);
    const max = items.reduce((a, i) => a + i.max, 0);
    return {
      courseCode: c.code,
      courseName: c.name,
      items,
      total: got,
      max,
      pct: max ? Math.round((got / max) * 1000) / 10 : 0,
    };
  });

  const allClassInt: { got: number; max: number }[] = [];
  const perClassStudent = new Map<string, { got: number; max: number }>();
  for (const m of classInternal) {
    const t = perClassStudent.get(m.studentId) ?? { got: 0, max: 0 };
    t.got += m.marksObtained;
    t.max += m.maxMarks;
    perClassStudent.set(m.studentId, t);
  }
  for (const t of perClassStudent.values()) if (t.max > 0) allClassInt.push(t);
  const classInternalAvgPct = allClassInt.length
    ? Math.round((allClassInt.reduce((a, t) => a + t.got / t.max, 0) / allClassInt.length) * 1000) / 10
    : 0;

  // ---- exams + semester aggregates + rank ----
  const myExamsFormatted = myExams.map((e) => ({
    semester: e.semester,
    academicYear: e.academicYear,
    examType: e.examType,
    courseCode: e.course.code,
    courseName: e.course.name,
    marks: e.marksObtained,
    maxMarks: e.maxMarks,
    pct: Math.round((e.marksObtained / e.maxMarks) * 1000) / 10,
    grade: e.grade,
    gradePoint: e.gradePoint,
  }));

  const bySem = new Map<number, { gp: number; credits: number; pctSum: number; n: number }>();
  for (const e of myExams) {
    const t = bySem.get(e.semester) ?? { gp: 0, credits: 0, pctSum: 0, n: 0 };
    t.gp += e.gradePoint * e.credits;
    t.credits += e.credits;
    t.pctSum += (e.marksObtained / e.maxMarks) * 100;
    t.n++;
    bySem.set(e.semester, t);
  }
  const yearOf: Record<number, string> = { 1: "2024-25", 2: "2024-25", 3: "2025-26", 4: "2025-26", 5: "2026-27" };
  const semesters = [...bySem.keys()].sort().map((sem) => {
    const t = bySem.get(sem)!;
    return {
      semester: sem,
      academicYear: yearOf[sem] ?? "2026-27",
      sgpa: t.credits ? Math.round((t.gp / t.credits) * 100) / 100 : 0,
      avgPct: t.n ? Math.round((t.pctSum / t.n) * 10) / 10 : 0,
    };
  });

  // class semester averages (for comparison) + SGPA rank
  const classBySemStudent = new Map<string, Map<number, { gp: number; credits: number }>>();
  for (const e of classExams) {
    const sems = classBySemStudent.get(e.studentId) ?? new Map();
    const t = sems.get(e.semester) ?? { gp: 0, credits: 0 };
    t.gp += e.gradePoint * e.credits;
    t.credits += e.credits;
    sems.set(e.semester, t);
    classBySemStudent.set(e.studentId, sems);
  }
  const classSemAvg = new Map<number, { gpSum: number; n: number; pctSum: number }>();
  for (const sems of classBySemStudent.values()) {
    for (const [sem, t] of sems) {
      if (!t.credits) continue;
      const sgpa = t.gp / t.credits;
      const c = classSemAvg.get(sem) ?? { gpSum: 0, n: 0, pctSum: 0 };
      c.gpSum += sgpa;
      c.n++;
      classSemAvg.set(sem, c);
    }
  }
  const classSemesters = [...classSemAvg.entries()].map(([sem, v]) => ({
    semester: sem,
    avgSgpa: Math.round((v.gpSum / v.n) * 100) / 100,
    avgPct: Math.round((v.pctSum / v.n) * 10) / 10,
  }));

  const mySem5 = semesters.find((s) => s.semester === 5)?.sgpa ?? 0;
  let rank = 1;
  for (const [, sems] of classBySemStudent) {
    const t = sems.get(5);
    if (!t || !t.credits) continue;
    if (t.gp / t.credits > mySem5) rank++;
  }

  // ---- attendance records for trend ----
  const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  const recentAttendance = [...myAttendance]
    .sort((a, b) => b.date.getTime() - a.date.getTime())
    .slice(0, 30)
    .map((a) => ({
      date: a.date.toISOString().slice(0, 10),
      label: `${monthNames[a.date.getUTCMonth()]} ${a.date.getUTCDate()}`,
      courseCode: currentCourses.find((c) => c.id === a.courseId)?.code ?? "",
      status: a.status,
      note: a.note,
    }));

  const totalPresent = myAttendance.filter((a) => a.status !== "ABSENT").length;

  return Response.json({
    profile: {
      name: user.name,
      email: user.email,
      rollNo: student.rollNo,
      department: student.department,
      semester: student.semester,
      section: student.section,
    },
    courses,
    internalMarks,
    internalTotal,
    internalMax,
    internalPct: internalMax ? Math.round((internalTotal / internalMax) * 1000) / 10 : 0,
    classInternalAvgPct,
    overallAttendancePct: myAttendance.length
      ? Math.round((totalPresent / myAttendance.length) * 1000) / 10
      : 0,
    exams: myExamsFormatted,
    semesters,
    classSemesters,
    rank: { position: rank, of: perClassStudent.size },
    recentAttendance,
  });
}
