import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { getSessionUser, unauthorized, badRequest } from "@/lib/auth";

function gradeOf(pct: number): { grade: string; gp: number } {
  if (pct >= 90) return { grade: "O", gp: 10 };
  if (pct >= 80) return { grade: "A+", gp: 9 };
  if (pct >= 70) return { grade: "A", gp: 8 };
  if (pct >= 60) return { grade: "B+", gp: 7 };
  if (pct >= 50) return { grade: "B", gp: 6 };
  if (pct >= 40) return { grade: "C", gp: 5 };
  return { grade: "F", gp: 0 };
}

/** GET exam result records. Filters: semester, examType, courseId (all optional). */
export async function GET(req: NextRequest) {
  const user = await getSessionUser(req, "FACULTY");
  if (!user) return unauthorized();

  const sp = req.nextUrl.searchParams;
  const where: Record<string, string | number> = {};
  const semester = sp.get("semester");
  const examType = sp.get("examType");
  const courseId = sp.get("courseId");
  if (semester) where.semester = Number(semester);
  if (examType) where.examType = examType;
  if (courseId) where.courseId = courseId;

  const results = await db.examResult.findMany({
    where,
    orderBy: [{ semester: "desc" }, { courseId: "asc" }],
    take: 800,
    include: {
      student: { include: { user: true } },
      course: true,
    },
  });

  return Response.json({
    rows: results.map((r) => ({
      id: r.id,
      studentId: r.studentId,
      rollNo: r.student.rollNo,
      name: r.student.user.name,
      section: r.student.section,
      courseId: r.courseId,
      courseCode: r.course.code,
      courseName: r.course.name,
      examType: r.examType,
      semester: r.semester,
      academicYear: r.academicYear,
      maxMarks: r.maxMarks,
      marksObtained: r.marksObtained,
      grade: r.grade,
    })),
  });
}

/** POST { records: [{studentId, courseId, examType, semester, academicYear, maxMarks, marksObtained}] } */
export async function POST(req: NextRequest) {
  const user = await getSessionUser(req, "FACULTY");
  if (!user) return unauthorized();

  const body = await req.json();
  const records: {
    studentId: string; courseId: string; examType: string; semester: number;
    academicYear: string; maxMarks: number; marksObtained: number;
  }[] = Array.isArray(body.records) ? body.records : [];
  if (records.length === 0) return badRequest("No records provided");

  const validExamTypes = ["MID_SEMESTER", "END_SEMESTER"];
  let saved = 0;
  for (const r of records) {
    if (!r.studentId || !r.courseId || !validExamTypes.includes(r.examType)) continue;
    const course = await db.course.findUnique({ where: { id: r.courseId } });
    if (!course) continue;
    const max = Number(r.maxMarks) || 100;
    const marks = Number(r.marksObtained);
    if (Number.isNaN(marks) || marks < 0 || marks > max) return badRequest(`Marks must be 0-${max}`);
    const g = gradeOf((marks / max) * 100);
    await db.examResult.upsert({
      where: {
        studentId_courseId_examType_academicYear: {
          studentId: r.studentId, courseId: r.courseId, examType: r.examType, academicYear: r.academicYear,
        },
      },
      create: {
        studentId: r.studentId, courseId: r.courseId, examType: r.examType,
        semester: Number(r.semester) || course.semester, academicYear: r.academicYear,
        maxMarks: max, marksObtained: marks, grade: g.grade, gradePoint: g.gp, credits: course.credits,
      },
      update: {
        maxMarks: max, marksObtained: marks, grade: g.grade, gradePoint: g.gp,
        semester: Number(r.semester) || course.semester,
      },
    });
    saved++;
  }
  return Response.json({ saved });
}
