import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { getSessionUser, unauthorized } from "@/lib/auth";

function sgpaOf(rows: { gradePoint: number; credits: number }[]) {
  const credits = rows.reduce((a, r) => a + r.credits, 0);
  if (!credits) return 0;
  return Math.round((rows.reduce((a, r) => a + r.gradePoint * r.credits, 0) / credits) * 100) / 100;
}

/** All students with overall attendance %, internal %, latest & previous SGPA. */
export async function GET(req: NextRequest) {
  const user = await getSessionUser(req, "FACULTY");
  if (!user) return unauthorized();

  const courses = await db.course.findMany({ where: { semester: 5 } });
  const courseIds = courses.map((c) => c.id);

  const [students, attendance, internal, exams] = await Promise.all([
    db.studentProfile.findMany({ include: { user: true }, orderBy: { rollNo: "asc" } }),
    db.attendance.findMany({ where: { courseId: { in: courseIds } } }),
    db.internalMark.findMany({ where: { courseId: { in: courseIds } } }),
    db.examResult.findMany({ where: { semester: { in: [4, 5] } } }),
  ]);

  const attByStudent = new Map<string, { present: number; total: number }>();
  for (const a of attendance) {
    const t = attByStudent.get(a.studentId) ?? { present: 0, total: 0 };
    t.total++;
    if (a.status !== "ABSENT") t.present++;
    attByStudent.set(a.studentId, t);
  }
  const intByStudent = new Map<string, { got: number; max: number }>();
  for (const m of internal) {
    const t = intByStudent.get(m.studentId) ?? { got: 0, max: 0 };
    t.got += m.marksObtained;
    t.max += m.maxMarks;
    intByStudent.set(m.studentId, t);
  }
  const examsByStudent = new Map<string, { gradePoint: number; credits: number; semester: number }[]>();
  for (const e of exams) {
    const arr = examsByStudent.get(e.studentId) ?? [];
    arr.push({ gradePoint: e.gradePoint, credits: e.credits, semester: e.semester });
    examsByStudent.set(e.studentId, arr);
  }

  const rows = students.map((s) => {
    const att = attByStudent.get(s.id);
    const int = intByStudent.get(s.id);
    const semExams = examsByStudent.get(s.id) ?? [];
    const latest = sgpaOf(semExams.filter((e) => e.semester === 5));
    const prev = sgpaOf(semExams.filter((e) => e.semester === 4));
    const attendancePct = att && att.total ? Math.round((att.present / att.total) * 1000) / 10 : 0;
    const internalPct = int && int.max ? Math.round((int.got / int.max) * 1000) / 10 : 0;
    const trend = latest > prev + 0.05 ? "up" : latest < prev - 0.05 ? "down" : "flat";
    return {
      studentId: s.id,
      userId: s.userId,
      rollNo: s.rollNo,
      name: s.user.name,
      email: s.user.email,
      section: s.section,
      semester: s.semester,
      attendancePct,
      internalPct,
      latestSgpa: latest,
      prevSgpa: prev,
      trend,
    };
  });

  return Response.json({ rows });
}
