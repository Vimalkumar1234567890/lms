import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { getSessionUser, unauthorized, badRequest } from "@/lib/auth";

const ISO_DATE = /^\d{4}-\d{2}-\d{2}$/;

/** GET roster with existing attendance for a course on a date. */
export async function GET(req: NextRequest) {
  const user = await getSessionUser(req, "FACULTY");
  if (!user) return unauthorized();

  const courseId = req.nextUrl.searchParams.get("courseId");
  const date = req.nextUrl.searchParams.get("date");
  if (!courseId || !date || !ISO_DATE.test(date)) return badRequest("courseId and date (YYYY-MM-DD) required");

  const course = await db.course.findUnique({ where: { id: courseId } });
  if (!course) return badRequest("Course not found");

  const enrollments = await db.enrollment.findMany({
    where: { courseId },
    include: { student: { include: { user: true } } },
    orderBy: { student: { rollNo: "asc" } },
  });
  const existing = await db.attendance.findMany({
    where: { courseId, date: new Date(date + "T00:00:00.000Z") },
  });
  const byStudent = new Map(existing.map((a) => [a.studentId, a]));

  return Response.json({
    course: { id: course.id, code: course.code, name: course.name },
    date,
    roster: enrollments.map((e) => {
      const rec = byStudent.get(e.studentId);
      return {
        studentId: e.studentId,
        rollNo: e.student.rollNo,
        name: e.student.user.name,
        section: e.student.section,
        status: (rec?.status as "PRESENT" | "ABSENT" | "LATE" | undefined) ?? null,
        note: rec?.note ?? "",
      };
    }),
    alreadyMarked: existing.length > 0,
  });
}

/** POST bulk attendance save (upsert). */
export async function POST(req: NextRequest) {
  const user = await getSessionUser(req, "FACULTY");
  if (!user) return unauthorized();
  const facultyId = user.facultyProfile?.id;
  if (!facultyId) return badRequest("Faculty profile missing");

  const body = await req.json();
  const courseId = String(body.courseId ?? "");
  const date = String(body.date ?? "");
  const records: { studentId: string; status: string; note?: string }[] = Array.isArray(body.records)
    ? body.records
    : [];
  if (!courseId || !ISO_DATE.test(date)) return badRequest("courseId and valid date required");
  if (records.length === 0) return badRequest("No records to save");

  const validStatus = ["PRESENT", "ABSENT", "LATE"];
  const course = await db.course.findUnique({ where: { id: courseId } });
  if (!course) return badRequest("Course not found");

  const dateObj = new Date(date + "T00:00:00.000Z");
  let saved = 0;
  for (const r of records) {
    if (!r.studentId || !validStatus.includes(r.status)) continue;
    await db.attendance.upsert({
      where: { studentId_courseId_date: { studentId: r.studentId, courseId, date: dateObj } },
      create: {
        studentId: r.studentId,
        courseId,
        date: dateObj,
        status: r.status,
        note: r.note?.trim() || null,
        markedById: facultyId,
      },
      update: { status: r.status, note: r.note?.trim() || null, markedById: facultyId },
    });
    saved++;
  }
  return Response.json({ saved, date, courseCode: course.code });
}
