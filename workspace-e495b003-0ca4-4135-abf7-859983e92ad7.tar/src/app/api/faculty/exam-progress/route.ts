import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { getSessionUser, unauthorized } from "@/lib/auth";

function sgpaOf(rows: { gradePoint: number; credits: number }[]) {
  const credits = rows.reduce((a, r) => a + r.credits, 0);
  if (!credits) return 0;
  return Math.round((rows.reduce((a, r) => a + r.gradePoint * r.credits, 0) / credits) * 100) / 100;
}

/** GET ?studentId=  → per-semester progress (class-level if studentId omitted). */
export async function GET(req: NextRequest) {
  const user = await getSessionUser(req, "FACULTY");
  if (!user) return unauthorized();

  const studentId = req.nextUrl.searchParams.get("studentId");
  const results = await db.examResult.findMany({
    where: studentId ? { studentId } : undefined,
    include: { course: true, student: { include: { user: true } } },
    orderBy: [{ semester: "asc" }, { course: { code: "asc" } }],
  });

  // group by semester
  const bySem = new Map<number, typeof results>();
  for (const r of results) {
    const arr = bySem.get(r.semester) ?? [];
    arr.push(r);
    bySem.set(r.semester, arr);
  }

  const yearOf: Record<number, string> = { 1: "2024-25", 2: "2024-25", 3: "2025-26", 4: "2025-26", 5: "2026-27" };
  const semesters = [...bySem.keys()].sort().map((sem) => {
    const rows = bySem.get(sem)!;
    const avgPct =
      Math.round((rows.reduce((a, r) => a + (r.marksObtained / r.maxMarks) * 100, 0) / rows.length) * 10) / 10;
    const best = rows.reduce((a, r) => ((r.marksObtained / r.maxMarks) > (a.marksObtained / a.maxMarks) ? r : a));
    const worst = rows.reduce((a, r) => ((r.marksObtained / r.maxMarks) < (a.marksObtained / a.maxMarks) ? r : a));
    return {
      semester: sem,
      academicYear: yearOf[sem] ?? "2026-27",
      avgPct,
      sgpa: sgpaOf(rows.map((r) => ({ gradePoint: r.gradePoint, credits: r.credits }))),
      courses: rows.length,
      bestSubject: best.course.code,
      bestPct: Math.round((best.marksObtained / best.maxMarks) * 1000) / 10,
      weakSubject: worst.course.code,
      weakPct: Math.round((worst.marksObtained / worst.maxMarks) * 1000) / 10,
    };
  });

  const byCourse = studentId
    ? results.map((r) => ({
        semester: r.semester,
        academicYear: r.academicYear,
        examType: r.examType,
        courseCode: r.course.code,
        courseName: r.course.name,
        marks: r.marksObtained,
        maxMarks: r.maxMarks,
        pct: Math.round((r.marksObtained / r.maxMarks) * 1000) / 10,
        grade: r.grade,
      }))
    : undefined;

  return Response.json({ studentId, semesters, byCourse });
}
