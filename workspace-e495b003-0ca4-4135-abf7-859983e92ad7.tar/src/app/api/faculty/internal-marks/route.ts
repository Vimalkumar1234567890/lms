import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { getSessionUser, unauthorized, badRequest } from "@/lib/auth";

export const ASSESSMENT_DEFS: Record<string, { title: string; max: number }> = {
  QUIZ_1: { title: "Quiz 1", max: 10 },
  QUIZ_2: { title: "Quiz 2", max: 10 },
  ASSIGNMENT: { title: "Assignment", max: 20 },
  LAB: { title: "Lab Evaluation", max: 25 },
  MID_TERM: { title: "Mid-Term Exam", max: 30 },
};
const MAX_TOTAL = Object.values(ASSESSMENT_DEFS).reduce((a, d) => a + d.max, 0);

/** GET ?courseId=&assessmentType=QUIZ_1  → editable sheet for one assessment
 *  GET ?courseId=&view=summary          → internal totals per student */
export async function GET(req: NextRequest) {
  const user = await getSessionUser(req, "FACULTY");
  if (!user) return unauthorized();

  const sp = req.nextUrl.searchParams;
  const courseId = sp.get("courseId");
  if (!courseId) return badRequest("courseId required");
  const course = await db.course.findUnique({ where: { id: courseId } });
  if (!course) return badRequest("Course not found");

  const enrollments = await db.enrollment.findMany({
    where: { courseId },
    include: { student: { include: { user: true } } },
    orderBy: { student: { rollNo: "asc" } },
  });

  if (sp.get("view") === "summary") {
    const marks = await db.internalMark.findMany({ where: { courseId } });
    const byStudent = new Map<string, { got: number; max: number; perType: Record<string, number> }>();
    const typeSums = new Map<string, { got: number; max: number; count: number }>();
    for (const m of marks) {
      const t = byStudent.get(m.studentId) ?? { got: 0, max: 0, perType: {} };
      t.got += m.marksObtained;
      t.max += m.maxMarks;
      t.perType[m.assessmentType] = m.marksObtained;
      byStudent.set(m.studentId, t);
      const ts = typeSums.get(m.assessmentType) ?? { got: 0, max: m.maxMarks, count: 0 };
      ts.got += m.marksObtained;
      ts.count++;
      typeSums.set(m.assessmentType, ts);
    }
    const rows = enrollments.map((e) => {
      const t = byStudent.get(e.studentId);
      return {
        studentId: e.studentId,
        rollNo: e.student.rollNo,
        name: e.student.user.name,
        section: e.student.section,
        perType: t?.perType ?? {},
        total: t?.got ?? 0,
        pct: t && t.max ? Math.round((t.got / t.max) * 1000) / 10 : 0,
      };
    });
    const classAvg = rows.length
      ? Math.round((rows.reduce((a, r) => a + r.pct, 0) / rows.length) * 10) / 10
      : 0;
    return Response.json({
      course: { id: course.id, code: course.code, name: course.name },
      maxTotal: MAX_TOTAL,
      rows,
      classAvg,
      typeAverages: [...typeSums.entries()].map(([type, v]) => ({
        type,
        title: ASSESSMENT_DEFS[type]?.title ?? type,
        avg: v.count ? Math.round((v.got / v.count) * 10) / 10 : 0,
        max: v.max,
      })),
    });
  }

  const assessmentType = sp.get("assessmentType") ?? "";
  const def = ASSESSMENT_DEFS[assessmentType];
  if (!def) return badRequest("assessmentType must be one of " + Object.keys(ASSESSMENT_DEFS).join(", "));

  const marks = await db.internalMark.findMany({ where: { courseId, assessmentType } });
  const byStudent = new Map(marks.map((m) => [m.studentId, m]));
  const values = marks.map((m) => m.marksObtained);

  return Response.json({
    course: { id: course.id, code: course.code, name: course.name },
    assessment: { type: assessmentType, title: def.title, max: def.max },
    rows: enrollments.map((e) => ({
      studentId: e.studentId,
      rollNo: e.student.rollNo,
      name: e.student.user.name,
      section: e.student.section,
      marks: byStudent.get(e.studentId)?.marksObtained ?? null,
    })),
    stats: {
      submitted: marks.length,
      avg: values.length ? Math.round((values.reduce((a, v) => a + v, 0) / values.length) * 10) / 10 : 0,
      highest: values.length ? Math.max(...values) : 0,
      lowest: values.length ? Math.min(...values) : 0,
    },
  });
}

/** POST { courseId, assessmentType, records: [{studentId, marks}] } — bulk upsert. */
export async function POST(req: NextRequest) {
  const user = await getSessionUser(req, "FACULTY");
  if (!user) return unauthorized();

  const body = await req.json();
  const courseId = String(body.courseId ?? "");
  const assessmentType = String(body.assessmentType ?? "");
  const records: { studentId: string; marks: number | null }[] = Array.isArray(body.records) ? body.records : [];
  const def = ASSESSMENT_DEFS[assessmentType];
  if (!courseId || !def) return badRequest("courseId and valid assessmentType required");
  const course = await db.course.findUnique({ where: { id: courseId } });
  if (!course) return badRequest("Course not found");

  let saved = 0;
  for (const r of records) {
    if (!r.studentId) continue;
    const where = { studentId_courseId_assessmentType: { studentId: r.studentId, courseId, assessmentType } };
    if (r.marks === null || r.marks === undefined || r.marks === ("")) {
      // empty cell → skip if not exists; remove existing record otherwise
      const existing = await db.internalMark.findUnique({ where });
      if (existing) {
        await db.internalMark.delete({ where: { id: existing.id } });
        saved++;
      }
      continue;
    }
    const marks = Number(r.marks);
    if (marks < 0 || marks > def.max) return badRequest(`Marks must be between 0 and ${def.max}`);
    await db.internalMark.upsert({
      where,
      create: {
        studentId: r.studentId, courseId, assessmentType, title: def.title,
        maxMarks: def.max, marksObtained: marks,
      },
      update: { marksObtained: marks, title: def.title, maxMarks: def.max },
    });
    saved++;
  }
  return Response.json({ saved, assessment: def.title, courseCode: course.code });
}
