import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { getSessionUser, unauthorized, badRequest } from "@/lib/auth";

/** Full academic profile for one student (faculty drill-down dialog). */
export async function GET(req: NextRequest) {
  const user = await getSessionUser(req, "FACULTY");
  if (!user) return unauthorized();

  const studentId = req.nextUrl.searchParams.get("studentId");
  if (!studentId) return badRequest("studentId required");

  const student = await db.studentProfile.findUnique({
    where: { id: studentId },
    include: { user: true },
  });
  if (!student) return badRequest("Student not found");

  const [attendance, internal, exams] = await Promise.all([
    db.attendance.findMany({
      where: { studentId },
      include: { course: true },
      orderBy: { date: "desc" },
    }),
    db.internalMark.findMany({
      where: { studentId },
      include: { course: true },
      orderBy: [{ courseId: "asc" }, { assessmentType: "asc" }],
    }),
    db.examResult.findMany({
      where: { studentId },
      include: { course: true },
      orderBy: [{ semester: "asc" }, { course: { code: "asc" } }],
    }),
  ]);

  // attendance per course
  const attByCourse = new Map<string, { code: string; name: string; present: number; late: number; absent: number }>();
  for (const a of attendance) {
    const t = attByCourse.get(a.courseId) ?? { code: a.course.code, name: a.course.name, present: 0, late: 0, absent: 0 };
    if (a.status === "PRESENT") t.present++;
    else if (a.status === "LATE") t.late++;
    else t.absent++;
    attByCourse.set(a.courseId, t);
  }
  const attendanceByCourse = [...attByCourse.values()].map((t) => {
    const total = t.present + t.late + t.absent;
    return { ...t, total, pct: total ? Math.round(((t.present + t.late) / total) * 1000) / 10 : 0 };
  });

  // internal per course
  const intByCourse = new Map<string, { code: string; name: string; got: number; max: number; perType: Record<string, number> }>();
  for (const m of internal) {
    const t = intByCourse.get(m.courseId) ?? { code: m.course.code, name: m.course.name, got: 0, max: 0, perType: {} };
    t.got += m.marksObtained;
    t.max += m.maxMarks;
    t.perType[m.assessmentType] = m.marksObtained;
    intByCourse.set(m.courseId, t);
  }
  const internalByCourse = [...intByCourse.values()].map((t) => ({
    ...t,
    pct: t.max ? Math.round((t.got / t.max) * 1000) / 10 : 0,
  }));

  // semester aggregates (SGPA)
  const bySem = new Map<number, { gp: number; credits: number; pctSum: number; n: number }>();
  for (const e of exams) {
    const t = bySem.get(e.semester) ?? { gp: 0, credits: 0, pctSum: 0, n: 0 };
    t.gp += e.gradePoint * e.credits;
    t.credits += e.credits;
    t.pctSum += (e.marksObtained / e.maxMarks) * 100;
    t.n++;
    bySem.set(e.semester, t);
  }
  const semesters = [...bySem.keys()].sort().map((sem) => {
    const t = bySem.get(sem)!;
    return {
      semester: sem,
      sgpa: t.credits ? Math.round((t.gp / t.credits) * 100) / 100 : 0,
      avgPct: t.n ? Math.round((t.pctSum / t.n) * 10) / 10 : 0,
    };
  });

  return Response.json({
    profile: {
      studentId: student.id,
      name: student.user.name,
      email: student.user.email,
      rollNo: student.rollNo,
      department: student.department,
      semester: student.semester,
      section: student.section,
      phone: student.phone,
      guardian: student.guardian,
    },
    attendanceByCourse,
    internalByCourse,
    exams: exams.map((e) => ({
      semester: e.semester,
      academicYear: e.academicYear,
      examType: e.examType,
      courseCode: e.course.code,
      courseName: e.course.name,
      marks: e.marksObtained,
      maxMarks: e.maxMarks,
      grade: e.grade,
    })),
    semesters,
    overallAttendancePct:
      attendance.length > 0
        ? Math.round((attendance.filter((a) => a.status !== "ABSENT").length / attendance.length) * 1000) / 10
        : 0,
    recentAttendance: attendance.slice(0, 15).map((a) => ({
      date: a.date.toISOString().slice(0, 10),
      courseCode: a.course.code,
      status: a.status,
    })),
  });
}
