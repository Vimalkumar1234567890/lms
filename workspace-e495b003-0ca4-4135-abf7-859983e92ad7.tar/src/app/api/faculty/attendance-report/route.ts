import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { getSessionUser, unauthorized, badRequest } from "@/lib/auth";

/** Attendance report for one course: per-student summary + class trend. */
export async function GET(req: NextRequest) {
  const user = await getSessionUser(req, "FACULTY");
  if (!user) return unauthorized();

  const courseId = req.nextUrl.searchParams.get("courseId");
  if (!courseId) return badRequest("courseId required");
  const course = await db.course.findUnique({ where: { id: courseId } });
  if (!course) return badRequest("Course not found");

  const [records, enrollments] = await Promise.all([
    db.attendance.findMany({ where: { courseId }, orderBy: { date: "asc" } }),
    db.enrollment.findMany({
      where: { courseId },
      include: { student: { include: { user: true } } },
      orderBy: { student: { rollNo: "asc" } },
    }),
  ]);

  const sessions = new Set(records.map((r) => r.date.toISOString().slice(0, 10)));
  const perStudent = new Map<string, { present: number; late: number; absent: number }>();
  const dayPct = new Map<string, { present: number; total: number }>();
  for (const r of records) {
    const s = perStudent.get(r.studentId) ?? { present: 0, late: 0, absent: 0 };
    if (r.status === "PRESENT") s.present++;
    else if (r.status === "LATE") s.late++;
    else s.absent++;
    perStudent.set(r.studentId, s);
    const day = r.date.toISOString().slice(0, 10);
    const d = dayPct.get(day) ?? { present: 0, total: 0 };
    d.total++;
    if (r.status !== "ABSENT") d.present++;
    dayPct.set(day, d);
  }

  const rows = enrollments.map((e) => {
    const s = perStudent.get(e.studentId) ?? { present: 0, late: 0, absent: 0 };
    const total = s.present + s.late + s.absent;
    return {
      studentId: e.studentId,
      rollNo: e.student.rollNo,
      name: e.student.user.name,
      section: e.student.section,
      present: s.present,
      late: s.late,
      absent: s.absent,
      total,
      pct: total ? Math.round(((s.present + s.late) / total) * 1000) / 10 : 0,
    };
  });

  const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  const trendDays = [...dayPct.keys()].sort().slice(-12);
  const sessionTrend = trendDays.map((day) => {
    const v = dayPct.get(day)!;
    const dt = new Date(day + "T00:00:00Z");
    return {
      date: day,
      label: `${monthNames[dt.getUTCMonth()]} ${dt.getUTCDate()}`,
      pct: v.total ? Math.round((v.present / v.total) * 1000) / 10 : 0,
    };
  });

  const totals = rows.reduce(
    (acc, r) => ({ present: acc.present + r.present, late: acc.late + r.late, absent: acc.absent + r.absent }),
    { present: 0, late: 0, absent: 0 }
  );
  const overall = totals.present + totals.late + totals.absent;

  return Response.json({
    course: { id: course.id, code: course.code, name: course.name },
    sessions: sessions.size,
    rows,
    classAvg: overall ? Math.round(((totals.present + totals.late) / overall) * 1000) / 10 : 0,
    sessionTrend,
    below75: rows.filter((r) => r.pct < 75).length,
    totals,
  });
}
