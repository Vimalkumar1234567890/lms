import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { getSessionUser, unauthorized } from "@/lib/auth";

interface CourseAgg {
  courseId: string;
  code: string;
  name: string;
  present: number;
  late: number;
  absent: number;
  internalSum: number;
  internalMax: number;
}

/** Faculty dashboard overview: department-wide stats, trends, at-risk lists. */
export async function GET(req: NextRequest) {
  const user = await getSessionUser(req, "FACULTY");
  if (!user) return unauthorized();

  const courses = await db.course.findMany({
    where: { semester: 5 },
    orderBy: { code: "asc" },
    include: { faculty: { include: { user: true } } },
  });
  const courseIds = courses.map((c) => c.id);

  const [attendance, internal, enrollments] = await Promise.all([
    db.attendance.findMany({ where: { courseId: { in: courseIds } }, orderBy: { date: "asc" } }),
    db.internalMark.findMany({ where: { courseId: { in: courseIds } } }),
    db.enrollment.findMany({ where: { courseId: { in: courseIds } } }),
  ]);

  const students = await db.studentProfile.findMany({ include: { user: true } });
  const studentMap = new Map(students.map((s) => [s.id, s]));

  // ---- per-course aggregation ----
  const agg = new Map<string, CourseAgg>();
  for (const c of courses) {
    agg.set(c.id, { courseId: c.id, code: c.code, name: c.name, present: 0, late: 0, absent: 0, internalSum: 0, internalMax: 0 });
  }
  const dayPct = new Map<string, { present: number; total: number }>();
  const perStudentAtt = new Map<string, { present: number; total: number }>();
  for (const a of attendance) {
    const g = agg.get(a.courseId);
    if (!g) continue;
    if (a.status === "PRESENT") g.present++;
    else if (a.status === "LATE") g.late++;
    else g.absent++;
    const dayKey = a.date.toISOString().slice(0, 10);
    const day = dayPct.get(dayKey) ?? { present: 0, total: 0 };
    day.total++;
    if (a.status !== "ABSENT") day.present++;
    dayPct.set(dayKey, day);
    const sa = perStudentAtt.get(a.studentId) ?? { present: 0, total: 0 };
    sa.total++;
    if (a.status !== "ABSENT") sa.present++;
    perStudentAtt.set(a.studentId, sa);
  }
  for (const m of internal) {
    const g = agg.get(m.courseId);
    if (!g) continue;
    g.internalSum += m.marksObtained;
    g.internalMax += m.maxMarks;
  }

  const courseStats = courses.map((c) => {
    const g = agg.get(c.id)!;
    const attTotal = g.present + g.late + g.absent;
    return {
      courseId: c.id,
      code: c.code,
      name: c.name,
      facultyName: c.faculty?.user.name ?? "Staff",
      isMine: c.facultyId === user.facultyProfile?.id,
      attendancePct: attTotal ? Math.round(((g.present + g.late) / attTotal) * 1000) / 10 : 0,
      internalPct: g.internalMax ? Math.round((g.internalSum / g.internalMax) * 1000) / 10 : 0,
      students: enrollments.filter((e) => e.courseId === c.id).length,
    };
  });

  // ---- attendance trend: last 14 class days ----
  const trendDays = [...dayPct.keys()].sort().slice(-14);
  const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  const trend = trendDays.map((day) => {
    const v = dayPct.get(day)!;
    return {
      date: day,
      label: `${monthNames[new Date(day + "T00:00:00Z").getUTCMonth()]} ${new Date(day + "T00:00:00Z").getUTCDate()}`,
      pct: v.total ? Math.round((v.present / v.total) * 1000) / 10 : 0,
    };
  });

  // ---- internal totals distribution ----
  const totalsByStudent = new Map<string, { got: number; max: number }>();
  for (const m of internal) {
    const t = totalsByStudent.get(m.studentId) ?? { got: 0, max: 0 };
    t.got += m.marksObtained;
    t.max += m.maxMarks;
    totalsByStudent.set(m.studentId, t);
  }
  const buckets = [
    { range: "90-100", lo: 90, hi: 100.01, count: 0 },
    { range: "80-89", lo: 80, hi: 90, count: 0 },
    { range: "70-79", lo: 70, hi: 80, count: 0 },
    { range: "60-69", lo: 60, hi: 70, count: 0 },
    { range: "50-59", lo: 50, hi: 60, count: 0 },
    { range: "<50", lo: 0, hi: 50, count: 0 },
  ];
  for (const t of totalsByStudent.values()) {
    if (!t.max) continue;
    const pct = (t.got / t.max) * 100;
    const b = buckets.find((b) => pct >= b.lo && pct < b.hi);
    if (b) b.count++;
  }

  // ---- at-risk: attendance < 75% ----
  const atRisk = students
    .map((s) => {
      const a = perStudentAtt.get(s.id);
      return a && a.total ? { s, pct: (a.present / a.total) * 100 } : null;
    })
    .filter((x): x is { s: (typeof students)[number]; pct: number } => !!x && x.pct < 75)
    .sort((x, y) => x.pct - y.pct)
    .slice(0, 8)
    .map(({ s, pct }) => ({
      studentId: s.id,
      name: s.user.name,
      rollNo: s.rollNo,
      section: s.section,
      attendancePct: Math.round(pct * 10) / 10,
    }));

  // ---- low performers: internal avg < 55% ----
  const lowPerformers = students
    .map((s) => {
      const t = totalsByStudent.get(s.id);
      return t && t.max ? { s, pct: (t.got / t.max) * 100 } : null;
    })
    .filter((x): x is { s: (typeof students)[number]; pct: number } => !!x && x.pct < 55)
    .sort((x, y) => x.pct - y.pct)
    .slice(0, 6)
    .map(({ s, pct }) => ({
      studentId: s.id,
      name: s.user.name,
      rollNo: s.rollNo,
      internalPct: Math.round(pct * 10) / 10,
    }));

  const totalAtt = attendance.reduce(
    (acc, a) => ({ present: acc.present + (a.status === "ABSENT" ? 0 : 1), total: acc.total + 1 }),
    { present: 0, total: 0 }
  );
  const internalTotals = [...totalsByStudent.values()].filter((t) => t.max > 0);

  return Response.json({
    totals: {
      students: students.length,
      faculty: await db.facultyProfile.count(),
      courses: courses.length,
      classSessions: dayPct.size,
      avgAttendance: totalAtt.total ? Math.round((totalAtt.present / totalAtt.total) * 1000) / 10 : 0,
      avgInternal: internalTotals.length
        ? Math.round(
            (internalTotals.reduce((acc, t) => acc + t.got / t.max, 0) / internalTotals.length) * 1000
          ) / 10
        : 0,
      atRiskCount: atRisk.length,
      todayMarked: dayPct.has(new Date().toISOString().slice(0, 10)),
    },
    trend,
    courseStats,
    gradeDist: buckets.map((b) => ({ range: b.range, count: b.count })),
    atRisk,
    lowPerformers,
  });
}
