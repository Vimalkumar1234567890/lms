import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { getSessionUser, unauthorized } from "@/lib/auth";

/** Current-semester course list with instructor names (shared by faculty & student). */
export async function GET(req: NextRequest) {
  const user = await getSessionUser(req);
  if (!user) return unauthorized();

  const courses = await db.course.findMany({
    where: { semester: 5 },
    orderBy: { code: "asc" },
    include: { faculty: { include: { user: true } } },
  });

  return Response.json({
    courses: courses.map((c) => ({
      id: c.id,
      code: c.code,
      name: c.name,
      credits: c.credits,
      semester: c.semester,
      facultyName: c.faculty?.user.name ?? "Staff",
      facultyId: c.facultyId,
    })),
  });
}
