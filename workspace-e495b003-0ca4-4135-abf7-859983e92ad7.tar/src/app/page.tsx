"use client";

import { useEffect, useState } from "react";
import LoginView from "@/components/lms/login";
import FacultyDashboard from "@/components/lms/faculty/shell";
import StudentDashboard from "@/components/lms/student";
import { loadSession, clearSession, type Session } from "@/lib/lms";

export default function Home() {
  const [session, setSession] = useState<Session | null>(null);
  const [booted, setBooted] = useState(false);

  // restore session once on mount (client only; must run after hydration)
  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setSession(loadSession());
    setBooted(true);
  }, []);

  if (!booted) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="w-8 h-8 rounded-full border-2 border-emerald-600 border-t-transparent animate-spin" />
      </div>
    );
  }

  if (!session) {
    return <LoginView onLogin={setSession} />;
  }

  const logout = () => {
    clearSession();
    setSession(null);
  };

  return session.user.role === "FACULTY" ? (
    <FacultyDashboard session={session} onLogout={logout} />
  ) : (
    <StudentDashboard session={session} onLogout={logout} />
  );
}
