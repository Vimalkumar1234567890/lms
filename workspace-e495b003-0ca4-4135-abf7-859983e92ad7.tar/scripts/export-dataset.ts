/**
 * Export the LMS dataset to CSV files in /home/z/my-project/download/dataset/
 * Tables: users, faculty, students, courses, enrollments, attendance, internal_marks, exam_results
 */
import { PrismaClient } from "@prisma/client";
import { writeFileSync, mkdirSync } from "fs";

const db = new PrismaClient();
const OUT = "/home/z/my-project/download/dataset";
mkdirSync(OUT, { recursive: true });

function toCsv(headers: string[], rows: (string | number | null)[][]): string {
  const esc = (c: string | number | null) => {
    const s = c === null ? "" : String(c);
    return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  return [headers.join(","), ...rows.map((r) => r.map(esc).join(","))].join("\n");
}

const iso = (d: Date | null) => (d ? d.toISOString().slice(0, 10) : "");

// ---- users (credentials separated: store password hint, not hash) ----
const users = await db.user.findMany({
  orderBy: { email: "asc" },
  include: { facultyProfile: true, studentProfile: true },
});
writeFileSync(
  `${OUT}/users.csv`,
  toCsv(
    ["user_id", "role", "name", "email", "password", "employee_id", "department", "designation", "roll_no", "semester", "section", "phone"],
    users.map((u) => [
      u.id, u.role, u.name, u.email,
      u.role === "FACULTY" ? "faculty123" : "student123",
      u.facultyProfile?.employeeId ?? "", u.facultyProfile?.department ?? u.studentProfile?.department ?? "",
      u.facultyProfile?.designation ?? "",
      u.studentProfile?.rollNo ?? "", u.studentProfile?.semester ?? "", u.studentProfile?.section ?? "",
      u.facultyProfile?.phone ?? u.studentProfile?.phone ?? "",
    ])
  )
);

// ---- courses ----
const courses = await db.course.findMany({
  orderBy: [{ semester: "asc" }, { code: "asc" }],
  include: { faculty: { include: { user: true } } },
});
writeFileSync(
  `${OUT}/courses.csv`,
  toCsv(
    ["course_id", "code", "name", "credits", "semester", "department", "faculty_name", "is_current_semester"],
    courses.map((c) => [c.id, c.code, c.name, c.credits, c.semester, c.department, c.faculty?.user.name ?? "", c.semester === 5 ? "yes" : "no"])
  )
);

// ---- enrollments ----
const enrollments = await db.enrollment.findMany({
  include: { student: { include: { user: true } }, course: true },
  orderBy: [{ courseId: "asc" }, { studentId: "asc" }],
});
writeFileSync(
  `${OUT}/enrollments.csv`,
  toCsv(
    ["enrollment_id", "roll_no", "student_name", "course_code", "course_name", "enrolled_on"],
    enrollments.map((e) => [e.id, e.student.rollNo, e.student.user.name, e.course.code, e.course.name, iso(e.createdAt)])
  )
);

// ---- attendance ----
const att = await db.attendance.findMany({
  include: { student: { include: { user: true } }, course: true },
  orderBy: [{ date: "asc" }, { courseId: "asc" }, { studentId: "asc" }],
});
writeFileSync(
  `${OUT}/attendance.csv`,
  toCsv(
    ["attendance_id", "date", "course_code", "roll_no", "student_name", "status", "note"],
    att.map((a) => [a.id, iso(a.date), a.course.code, a.student.rollNo, a.student.user.name, a.status, a.note ?? ""])
  )
);

// ---- internal marks ----
const ims = await db.internalMark.findMany({
  include: { student: { include: { user: true } }, course: true },
  orderBy: [{ courseId: "asc" }, { studentId: "asc" }, { assessmentType: "asc" }],
});
writeFileSync(
  `${OUT}/internal_marks.csv`,
  toCsv(
    ["mark_id", "course_code", "course_name", "roll_no", "student_name", "assessment_type", "assessment_title", "max_marks", "marks_obtained", "percentage"],
    ims.map((m) => [
      m.id, m.course.code, m.course.name, m.student.rollNo, m.student.user.name,
      m.assessmentType, m.title, m.maxMarks, m.marksObtained,
      Math.round((m.marksObtained / m.maxMarks) * 1000) / 10,
    ])
  )
);

// ---- exam results ----
const exams = await db.examResult.findMany({
  include: { student: { include: { user: true } }, course: true },
  orderBy: [{ semester: "asc" }, { courseId: "asc" }, { studentId: "asc" }],
});
writeFileSync(
  `${OUT}/exam_results.csv`,
  toCsv(
    ["result_id", "academic_year", "semester", "exam_type", "course_code", "course_name", "roll_no", "student_name", "max_marks", "marks_obtained", "percentage", "grade", "grade_point", "credits"],
    exams.map((e) => [
      e.id, e.academicYear, e.semester, e.examType, e.course.code, e.course.name,
      e.student.rollNo, e.student.user.name, e.maxMarks, e.marksObtained,
      Math.round((e.marksObtained / e.maxMarks) * 1000) / 10,
      e.grade, e.gradePoint, e.credits,
    ])
  )
);

console.log("Exported:", {
  users: users.length,
  courses: courses.length,
  enrollments: enrollments.length,
  attendance: att.length,
  internalMarks: ims.length,
  examResults: exams.length,
});
process.exit(0);
