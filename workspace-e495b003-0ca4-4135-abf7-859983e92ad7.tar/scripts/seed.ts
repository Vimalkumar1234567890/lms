/**
 * LMS Seed Dataset
 * - 6 faculty, 40 students (CSE, Semester 5)
 * - 6 current courses + 17 historical courses (semesters 1-4)
 * - ~6 weeks of attendance history per course
 * - Internal marks (quizzes, assignment, lab, mid-term) for current semester
 * - Exam results (end-semester) for semesters 1-4 + mid-sem of current semester
 *
 * Run: bun scripts/seed.ts
 */
import { PrismaClient } from "@prisma/client";
import * as crypto from "crypto";

const db = new PrismaClient();

// ---------- deterministic RNG ----------
function mulberry32(seed: number) {
  return function () {
    let t = (seed += 0x6d2b79f5);
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
const rand = mulberry32(20261);
const rint = (min: number, max: number) => Math.floor(rand() * (max - min + 1)) + min;
const pick = <T,>(arr: T[]) => arr[Math.floor(rand() * arr.length)];

const hash = (pw: string) => crypto.createHash("sha256").update(`lms::${pw}`).digest("hex");

// ---------- helpers ----------
function gradeOf(pct: number): { grade: string; gp: number } {
  if (pct >= 90) return { grade: "O", gp: 10 };
  if (pct >= 80) return { grade: "A+", gp: 9 };
  if (pct >= 70) return { grade: "A", gp: 8 };
  if (pct >= 60) return { grade: "B+", gp: 7 };
  if (pct >= 50) return { grade: "B", gp: 6 };
  if (pct >= 40) return { grade: "C", gp: 5 };
  return { grade: "F", gp: 0 };
}
const clamp = (v: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, v));
const d = (iso: string) => new Date(iso + "T00:00:00.000Z");

// ---------- faculty ----------
const FACULTY = [
  { name: "Dr. Anil Sharma", email: "anil.sharma@lms.edu", employeeId: "FAC1001", designation: "Professor", dept: "Computer Science", phone: "+91 98450 11223" },
  { name: "Prof. Meera Iyer", email: "meera.iyer@lms.edu", employeeId: "FAC1002", designation: "Associate Professor", dept: "Computer Science", phone: "+91 98450 44556" },
  { name: "Dr. Rajesh Gupta", email: "rajesh.gupta@lms.edu", employeeId: "FAC1003", designation: "Professor", dept: "Computer Science", phone: "+91 98450 77889" },
  { name: "Prof. Kavita Rao", email: "kavita.rao@lms.edu", employeeId: "FAC1004", designation: "Assistant Professor", dept: "Computer Science", phone: "+91 98450 22334" },
  { name: "Dr. Sanjay Mishra", email: "sanjay.mishra@lms.edu", employeeId: "FAC1005", designation: "Associate Professor", dept: "Computer Science", phone: "+91 98450 66778" },
  { name: "Dr. Priya Nair", email: "priya.nair@lms.edu", employeeId: "FAC1006", designation: "Assistant Professor", dept: "Computer Science", phone: "+91 98450 99001" },
];

// ---------- current semester (5) courses ----------
const CURRENT_COURSES = [
  { code: "CS501", name: "Computer Networks", credits: 4, facultyIdx: 0 },
  { code: "CS502", name: "Operating Systems", credits: 4, facultyIdx: 1 },
  { code: "CS503", name: "Database Management Systems", credits: 4, facultyIdx: 2 },
  { code: "CS504", name: "Software Engineering", credits: 3, facultyIdx: 3 },
  { code: "CS505", name: "Theory of Computation", credits: 3, facultyIdx: 4 },
  { code: "CS506", name: "Machine Learning Fundamentals", credits: 3, facultyIdx: 5 },
];

// ---------- historical courses (semesters 1-4) ----------
const HISTORY_COURSES: Record<number, { code: string; name: string; credits: number }[]> = {
  1: [
    { code: "MA101", name: "Engineering Mathematics I", credits: 4 },
    { code: "CS101", name: "Programming Fundamentals", credits: 4 },
    { code: "PH102", name: "Engineering Physics", credits: 3 },
    { code: "EC103", name: "Basic Electronics", credits: 3 },
  ],
  2: [
    { code: "MA201", name: "Engineering Mathematics II", credits: 4 },
    { code: "CS201", name: "Object Oriented Programming", credits: 4 },
    { code: "CS202", name: "Digital Logic Design", credits: 3 },
    { code: "HS203", name: "Technical Communication", credits: 2 },
  ],
  3: [
    { code: "CS301", name: "Data Structures & Algorithms", credits: 4 },
    { code: "CS302", name: "Discrete Mathematics", credits: 3 },
    { code: "CS303", name: "Computer Organization", credits: 4 },
    { code: "IT304", name: "Web Technologies", credits: 3 },
  ],
  4: [
    { code: "CS401", name: "Microprocessors & Microcontrollers", credits: 3 },
    { code: "CS402", name: "Design & Analysis of Algorithms", credits: 4 },
    { code: "CS403", name: "Data Communication", credits: 3 },
    { code: "MA404", name: "Probability & Statistics", credits: 3 },
    { code: "CS405", name: "Java Programming", credits: 3 },
  ],
};

// ---------- students ----------
const STUDENT_NAMES = [
  "Aarav Mehta", "Ananya Sharma", "Arjun Reddy", "Diya Patel", "Ishaan Kapoor",
  "Kavya Nair", "Rohan Verma", "Sneha Iyer", "Aditya Kumar", "Priya Singh",
  "Vihaan Joshi", "Anika Das", "Kartik Malhotra", "Riya Chatterjee", "Dhruv Saxena",
  "Meera Pillai", "Arnav Bhatt", "Pooja Desai", "Kabir Anand", "Tara Menon",
  "Vivaan Rana", "Ishita Bose", "Yash Agarwal", "Neha Kulkarni", "Rehan Khan",
  "Shreya Ghosh", "Aryan Thakur", "Divya Hegde", "Manav Shetty", "Lara Fernandes",
  "Nikhil Chauhan", "Ritika Bansal", "Sidharth Rathore", "Aisha Sheikh", "Pranav Mohan",
  "Naina Awasthi", "Dev Pandey", "Sara Thomas", "Harsh Yadav", "Ojaswi Mishra",
];

type Archetype = "topper" | "good" | "average" | "weak" | "irregular";
// archetype per student index (40 students)
const ARCHETYPES: Archetype[] = [
  "topper", "good", "good", "average", "topper", "good", "average", "topper", "good", "average",
  "good", "average", "weak", "good", "average", "topper", "average", "good", "good", "average",
  "irregular", "good", "average", "topper", "weak", "good", "average", "good", "average", "good",
  "average", "topper", "irregular", "good", "average", "weak", "irregular", "average", "good", "weak",
];

const ARCHETYPE_CFG: Record<Archetype, { ability: number; attMean: number }> = {
  topper: { ability: 0.88, attMean: 0.95 },
  good: { ability: 0.76, attMean: 0.88 },
  average: { ability: 0.64, attMean: 0.79 },
  weak: { ability: 0.5, attMean: 0.68 },
  irregular: { ability: 0.52, attMean: 0.55 },
};

// internal assessments per course
const ASSESSMENTS = [
  { type: "QUIZ_1", title: "Quiz 1", max: 10, date: "2026-10-02" },
  { type: "QUIZ_2", title: "Quiz 2", max: 10, date: "2026-10-21" },
  { type: "ASSIGNMENT", title: "Assignment", max: 20, date: "2026-10-27" },
  { type: "LAB", title: "Lab Evaluation", max: 25, date: "2026-10-30" },
  { type: "MID_TERM", title: "Mid-Term Exam", max: 30, date: "2026-10-14" },
];

// class-session weekdays: 2026-09-28 .. 2026-11-04 (all weekdays)
function classDates(): string[] {
  const out: string[] = [];
  const start = d("2026-09-28").getTime();
  const end = d("2026-11-04").getTime();
  for (let t = start; t <= end; t += 86400000) {
    const day = new Date(t).getUTCDay();
    if (day !== 0 && day !== 6) out.push(new Date(t).toISOString().slice(0, 10));
  }
  return out;
}

async function main() {
  console.log("Clearing existing data...");
  await db.examResult.deleteMany();
  await db.internalMark.deleteMany();
  await db.attendance.deleteMany();
  await db.enrollment.deleteMany();
  await db.course.deleteMany();
  await db.studentProfile.deleteMany();
  await db.facultyProfile.deleteMany();
  await db.user.deleteMany();

  // ---------- users + faculty ----------
  console.log("Seeding faculty...");
  const facultyIds: string[] = [];
  for (const f of FACULTY) {
    const u = await db.user.create({
      data: { email: f.email, password: hash("faculty123"), name: f.name, role: "FACULTY" },
    });
    const p = await db.facultyProfile.create({
      data: {
        userId: u.id, employeeId: f.employeeId, department: f.dept,
        designation: f.designation, phone: f.phone,
      },
    });
    facultyIds.push(p.id);
  }

  // ---------- current courses ----------
  console.log("Seeding courses...");
  const currentCourses: { id: string; code: string; name: string; credits: number; facultyIdx: number }[] = [];
  for (const c of CURRENT_COURSES) {
    const created = await db.course.create({
      data: { code: c.code, name: c.name, credits: c.credits, semester: 5, department: "Computer Science", facultyId: facultyIds[c.facultyIdx] },
    });
    currentCourses.push({ id: created.id, code: c.code, name: c.name, credits: c.credits, facultyIdx: c.facultyIdx });
  }

  // historical courses (semester-tagged, no faculty assigned)
  const historyCourses: Record<number, { id: string; code: string; name: string; credits: number }[]> = {};
  for (const sem of [1, 2, 3, 4]) {
    historyCourses[sem] = [];
    for (const c of HISTORY_COURCES_SAFE(sem)) {
      const created = await db.course.create({
        data: { code: c.code, name: c.name, credits: c.credits, semester: sem, department: "Computer Science" },
      });
      historyCourses[sem].push({ id: created.id, code: c.code, name: c.name, credits: c.credits });
    }
  }

  // ---------- students ----------
  console.log("Seeding students...");
  const students: { profileId: string; userId: string; name: string; ability: number; attProb: number; idx: number }[] = [];
  for (let i = 0; i < STUDENT_NAMES.length; i++) {
    const name = STUDENT_NAMES[i];
    const email = name.toLowerCase().replace(/[^a-z ]/g, "").trim().replace(/ +/g, ".") + "@lms.edu";
    const roll = `24CSE${String(i + 1).padStart(3, "0")}`;
    const section = i < 20 ? "A" : "B";
    const cfg = ARCHETYPE_CFG[ARCHETYPES[i]];
    const ability = clamp(cfg.ability + (rand() - 0.5) * 0.08, 0.3, 0.99);      // stable academic ability
    const attProb = clamp(cfg.attMean + (rand() - 0.5) * 0.10, 0.35, 0.99);     // stable attendance habit
    const u = await db.user.create({
      data: { email, password: hash("student123"), name, role: "STUDENT" },
    });
    const p = await db.studentProfile.create({
      data: {
        userId: u.id, rollNo: roll, department: "Computer Science", semester: 5, section,
        phone: `+91 9${rint(100000000, 999999999)}`,
        guardian: pick(["Mr. ", "Mrs. "]) + name.split(" ")[1],
      },
    });
    students.push({ profileId: p.id, userId: u.id, name, ability, attProb, idx: i });
  }

  // ---------- enrollments ----------
  console.log("Seeding enrollments...");
  const enrollmentRows = students.flatMap((s) =>
    currentCourses.map((c) => ({ studentId: s.profileId, courseId: c.id }))
  );
  await db.enrollment.createMany({ data: enrollmentRows });

  // ---------- attendance ----------
  console.log("Seeding attendance...");
  const dates = classDates();
  const attRows: {
    studentId: string; courseId: string; date: Date; status: string; markedById: string; note?: string;
  }[] = [];
  for (const s of students) {
    for (const c of currentCourses) {
      const courseFactor = 0.96 + rand() * 0.08; // slight course-level variation
      for (let i = 0; i < dates.length; i++) {
        // improve slightly over time for some students (learning to be regular)
        const trend = s.attProb < 0.7 && i > dates.length * 0.6 ? 0.08 : 0;
        const p = clamp(s.attProb * courseFactor + trend, 0.3, 0.99);
        const r = rand();
        let status: string;
        if (r < p * 0.95) status = "PRESENT";
        else if (r < p) status = "LATE";
        else status = "ABSENT";
        const row: {
          studentId: string; courseId: string; date: Date; status: string; markedById: string; note?: string;
        } = {
          studentId: s.profileId, courseId: c.id, date: d(dates[i]), status,
          markedById: facultyIds[c.facultyIdx],
        };
        if (status === "ABSENT" && rand() < 0.08) row.note = pick(["Medical leave", "Family emergency", "Internship interview", "Not reachable"]);
        attRows.push(row);
      }
    }
  }
  for (let i = 0; i < attRows.length; i += 2000) {
    await db.attendance.createMany({ data: attRows.slice(i, i + 2000) });
  }
  console.log(`  ${attRows.length} attendance records`);

  // ---------- internal marks (current semester) ----------
  console.log("Seeding internal marks...");
  const imRows: {
    studentId: string; courseId: string; assessmentType: string; title: string;
    maxMarks: number; marksObtained: number; conductedOn: Date;
  }[] = [];
  for (const s of students) {
    for (const c of currentCourses) {
      for (const a of ASSESSMENTS) {
        const noise = (rand() - 0.5) * 0.18;
        const ratio = clamp(s.ability + noise + 0.04, 0.25, 0.995);
        imRows.push({
          studentId: s.profileId, courseId: c.id, assessmentType: a.type, title: a.title,
          maxMarks: a.max, marksObtained: Math.round(a.max * ratio * 2) / 2, conductedOn: d(a.date),
        });
      }
    }
  }
  for (let i = 0; i < imRows.length; i += 2000) {
    await db.internalMark.createMany({ data: imRows.slice(i, i + 2000) });
  }
  console.log(`  ${imRows.length} internal marks`);

  // ---------- exam results (progress history) ----------
  console.log("Seeding exam results...");
  const erRows: {
    studentId: string; courseId: string; examType: string; semester: number; academicYear: string;
    maxMarks: number; marksObtained: number; grade: string; gradePoint: number; credits: number;
  }[] = [];
  const yearOf: Record<number, string> = { 1: "2024-25", 2: "2024-25", 3: "2025-26", 4: "2025-26", 5: "2026-27" };
  for (const s of students) {
    // historical semesters: end-sem exams (ability matures slightly over time)
    for (const sem of [1, 2, 3, 4]) {
      const maturity = 1 + (sem - 5) * 0.012; // earlier semesters slightly weaker
      for (const c of historyCourses[sem]) {
        const ratio = clamp(s.ability * maturity + (rand() - 0.5) * 0.16, 0.22, 0.99);
        const marks = Math.round(ratio * 100 * 2) / 2;
        const g = gradeOf(marks);
        erRows.push({
          studentId: s.profileId, courseId: c.id, examType: "END_SEMESTER", semester: sem,
          academicYear: yearOf[sem], maxMarks: 100, marksObtained: marks, grade: g.grade, gradePoint: g.gp, credits: c.credits,
        });
      }
    }
    // current semester (5): mid-sem exam already conducted
    for (const c of currentCourses) {
      const ratio = clamp(s.ability + (rand() - 0.5) * 0.12, 0.25, 0.99);
      const marks = Math.round(ratio * 100 * 2) / 2;
      const g = gradeOf(marks);
      erRows.push({
        studentId: s.profileId, courseId: c.id, examType: "MID_SEMESTER", semester: 5,
        academicYear: "2026-27", maxMarks: 100, marksObtained: marks, grade: g.grade, gradePoint: g.gp, credits: c.credits,
      });
    }
  }
  for (let i = 0; i < erRows.length; i += 2000) {
    await db.examResult.createMany({ data: erRows.slice(i, i + 2000) });
  }
  console.log(`  ${erRows.length} exam results`);

  // ---------- summary ----------
  const counts = {
    users: await db.user.count(),
    faculty: await db.facultyProfile.count(),
    students: await db.studentProfile.count(),
    courses: await db.course.count(),
    enrollments: await db.enrollment.count(),
    attendance: await db.attendance.count(),
    internalMarks: await db.internalMark.count(),
    examResults: await db.examResult.count(),
  };
  console.log("Done!", JSON.stringify(counts, null, 2));
}

// keep the historical course table (moved out so TS Record typing is simple)
function HISTORY_COURCES_SAFE(sem: number) {
  return HISTORY_COURSES_DATA[sem];
}
const HISTORY_COURSES_DATA: Record<number, { code: string; name: string; credits: number }[]> = {
  1: [
    { code: "MA101", name: "Engineering Mathematics I", credits: 4 },
    { code: "CS101", name: "Programming Fundamentals", credits: 4 },
    { code: "PH102", name: "Engineering Physics", credits: 3 },
    { code: "EC103", name: "Basic Electronics", credits: 3 },
  ],
  2: [
    { code: "MA201", name: "Engineering Mathematics II", credits: 4 },
    { code: "CS201", name: "Object Oriented Programming", credits: 4 },
    { code: "CS202", name: "Digital Logic Design", credits: 3 },
    { code: "HS203", name: "Technical Communication", credits: 2 },
  ],
  3: [
    { code: "CS301", name: "Data Structures & Algorithms", credits: 4 },
    { code: "CS302", name: "Discrete Mathematics", credits: 3 },
    { code: "CS303", name: "Computer Organization", credits: 4 },
    { code: "IT304", name: "Web Technologies", credits: 3 },
  ],
  4: [
    { code: "CS401", name: "Microprocessors & Microcontrollers", credits: 3 },
    { code: "CS402", name: "Design & Analysis of Algorithms", credits: 4 },
    { code: "CS403", name: "Data Communication", credits: 3 },
    { code: "MA404", name: "Probability & Statistics", credits: 3 },
    { code: "CS405", name: "Java Programming", credits: 3 },
  ],
};

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => db.$disconnect());
