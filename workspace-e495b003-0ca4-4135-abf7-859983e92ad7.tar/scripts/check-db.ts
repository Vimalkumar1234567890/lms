import { PrismaClient } from "@prisma/client";
const db = new PrismaClient();
const counts = await Promise.all([
  db.user.count(),
  db.facultyProfile.count(),
  db.studentProfile.count(),
  db.course.count(),
  db.enrollment.count(),
  db.attendance.count(),
  db.internalMark.count(),
  db.examResult.count(),
]);
console.log(JSON.stringify({
  users: counts[0],
  faculty: counts[1],
  students: counts[2],
  courses: counts[3],
  enrollments: counts[4],
  attendance: counts[5],
  internalMarks: counts[6],
  examResults: counts[7],
}, null, 2));
process.exit(0);
