# EduTrack LMS — Demo Dataset

Synthetic dataset generated for the EduTrack LMS platform (Computer Science & Engineering, Semester 5, Academic Year 2026-27). All data is deterministic (seeded RNG) and fictional.

## Files

| File | Rows | Description |
| --- | --- | --- |
| `users.csv` | 46 | Login accounts: 6 faculty + 40 students, with roles and profile fields |
| `courses.csv` | 23 | 6 current-semester courses (CS501–CS506) + 17 historical courses (Sem 1–4) |
| `enrollments.csv` | 240 | Student–course enrollments for the current semester (40 students × 6 courses) |
| `attendance.csv` | 6,760 | Daily attendance (PRESENT / ABSENT / LATE) per student per course per date |
| `internal_marks.csv` | 1,200 | Continuous assessment: Quiz 1 (10), Quiz 2 (10), Mid-Term (30), Assignment (20), Lab (25) → total /95 |
| `exam_results.csv` | 923 | Past exam history: End-Semester results for Sem 1–4 + Mid-Semester of Sem 5, with grade & grade point |

## Grading scale

| % | Grade | Grade point |
| --- | --- | --- |
| ≥ 90 | O | 10 |
| ≥ 80 | A+ | 9 |
| ≥ 70 | A | 8 |
| ≥ 60 | B+ | 7 |
| ≥ 50 | B | 6 |
| ≥ 40 | C | 5 |
| < 40 | F | 0 |

## Demo logins (in-app)

- Faculty: `anil.sharma@lms.edu` / `faculty123` (also meera.iyer@, rajesh.gupta@, kavita.rao@, sanjay.mishra@, priya.nair@)
- Students: `aarav.mehta@lms.edu` / `student123` (roll 24CSE001 … 24CSE040; e.g. `vivaan.rana@lms.edu` is a low-attendance demo case)

## Attendance benchmark

75% is the minimum for exam eligibility — the platform flags anything below as "At Risk".
