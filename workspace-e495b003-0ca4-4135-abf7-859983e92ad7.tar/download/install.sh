#!/usr/bin/env bash
# =============================================================
#  EduTrack LMS — One-Command Installation Helper
#  Usage:  bash install.sh
#  Run this from the project root (the folder containing
#  package.json, prisma/ and src/).
# =============================================================
set -e

GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; NC='\033[0m'
ok()   { echo -e "${GREEN}[OK]${NC} $1"; }
warn() { echo -e "${YELLOW}[..]${NC} $1"; }
fail() { echo -e "${RED}[ERROR]${NC} $1"; exit 1; }

echo "=============================================="
echo "  EduTrack LMS — Installation Helper"
echo "=============================================="

# -- 0. Sanity check: are we in the project root? -------------
[ -f package.json ] || fail "package.json not found. cd into the project folder first (the one containing package.json)."
[ -d prisma ]       || fail "prisma/ folder not found — this doesn't look like the LMS project."
ok "Project folder found"

# -- 1. Check runtime (bun preferred, node fallback) ----------
RUNNER=""
PKG=""
if command -v bun >/dev/null 2>&1; then
  RUNNER="bun"; PKG="bun install"
  ok "Bun $(bun --version) detected"
elif command -v node >/dev/null 2>&1; then
  NODE_MAJOR=$(node -p 'process.versions.node.split(".")[0]')
  [ "$NODE_MAJOR" -ge 20 ] || fail "Node.js $(node --version) found but v20+ is required. Install from https://nodejs.org"
  RUNNER="node"
  ok "Node.js $(node --version) detected"
else
  fail "Neither Bun nor Node.js found.
       Install Bun:  curl -fsSL https://bun.sh/install | bash   (mac/Linux)
       or Node.js 20+ from https://nodejs.org"
fi

# -- 2. Install dependencies ----------------------------------
warn "Installing dependencies (this can take 1–3 minutes)…"
if [ "$RUNNER" = "bun" ]; then
  bun install
else
  npm install
fi
ok "Dependencies installed"

# -- 3. Create .env if missing --------------------------------
if [ ! -f .env ]; then
  echo 'DATABASE_URL=file:./db/custom.db' > .env
  ok "Created .env (SQLite database at db/custom.db)"
else
  ok ".env already exists — keeping it"
fi
mkdir -p db

# -- 4. Push database schema ----------------------------------
warn "Creating database tables…"
if [ "$RUNNER" = "bun" ]; then
  bun run db:push
else
  npx prisma db push --accept-data-loss --skip-generate
  npx prisma generate
fi
ok "Database schema created"

# -- 5. Seed demo dataset -------------------------------------
warn "Loading demo dataset (6 faculty, 40 students, ~9,000 records)…"
if [ "$RUNNER" = "bun" ]; then
  bun scripts/seed.ts
else
  if ! npx --no-install tsx --version >/dev/null 2>&1; then
    npm install --no-save tsx >/dev/null 2>&1
  fi
  npx tsx scripts/seed.ts
fi
ok "Demo dataset loaded"

# -- 6. Done ----------------------------------------------------
echo ""
echo "=============================================="
echo -e "${GREEN}  Installation complete!${NC}"
echo "=============================================="
echo ""
echo "  Start the app:      $([ "$RUNNER" = "bun" ] && echo "bun run dev" || echo "npm run dev")"
echo "  Then open:          http://localhost:3000"
echo ""
echo "  Faculty login:      anil.sharma@lms.edu  / faculty123"
echo "  Student login:      aarav.mehta@lms.edu  / student123"
echo "  (or use the one-click demo buttons on the sign-in page)"
echo ""
